import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests
import json
import gzip
import time
import os
from io import BytesIO
from urllib.parse import urlencode, parse_qsl

# Addon bilgileri
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_url = sys.argv[0]

class CanliTVAddon:
    def __init__(self):
        self.addon = addon
        self.handle = addon_handle
        self.url = addon_url
        
        # Cache ayarları
        self.cache_file = os.path.join(xbmcvfs.translatePath(self.addon.getAddonInfo('profile')), 'channels_cache.json')
        self.cache_duration = int(self.addon.getSetting('cache_time')) * 60  # dakikayı saniyeye çevir
        if self.cache_duration == 0:  # Ayar yoksa varsayılan 60 dakika
            self.cache_duration = 3600
        
        # Cache klasörünü oluştur
        cache_dir = os.path.dirname(self.cache_file)
        if not xbmcvfs.exists(cache_dir):
            xbmcvfs.mkdirs(cache_dir)
    
    def _save_cache(self, data):
        """Veriyi cache'e kaydet"""
        try:
            cache_data = {
                'timestamp': time.time(),
                'data': data
            }
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, ensure_ascii=False, indent=2)
            xbmc.log("CanliTV: Veriler cache'e kaydedildi", xbmc.LOGDEBUG)
            return True
        except Exception as e:
            xbmc.log(f"CanliTV Cache Kaydetme Hatası: {str(e)}", xbmc.LOGWARNING)
            return False
    
    def _load_cache(self):
        """Cache'den veriyi yükle"""
        try:
            if not os.path.exists(self.cache_file):
                xbmc.log("CanliTV: Cache dosyası bulunamadı", xbmc.LOGDEBUG)
                return None
            
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            
            # Cache süresi kontrolü
            cache_age = time.time() - cache_data.get('timestamp', 0)
            if cache_age > self.cache_duration:
                xbmc.log(f"CanliTV: Cache süresi dolmuş ({cache_age:.0f}s > {self.cache_duration}s)", xbmc.LOGDEBUG)
                return None
            
            xbmc.log(f"CanliTV: Cache'den veri yüklendi (yaş: {cache_age:.0f}s)", xbmc.LOGDEBUG)
            return cache_data.get('data')
            
        except Exception as e:
            xbmc.log(f"CanliTV Cache Yükleme Hatası: {str(e)}", xbmc.LOGWARNING)
            return None
    
    def _clear_cache(self):
        """Cache'i temizle"""
        try:
            if os.path.exists(self.cache_file):
                os.remove(self.cache_file)
                xbmc.log("CanliTV: Cache temizlendi", xbmc.LOGINFO)
                return True
        except Exception as e:
            xbmc.log(f"CanliTV Cache Temizleme Hatası: {str(e)}", xbmc.LOGWARNING)
            return False

    def get_channels(self, force_refresh=False):
        """CanliTV API'den kanal listesini al (cache ile)"""
        
        # Force refresh yoksa önce cache'i kontrol et
        if not force_refresh:
            cached_data = self._load_cache()
            if cached_data:
                xbmc.log(f"CanliTV: {len(cached_data)} kanal cache'den yüklendi", xbmc.LOGINFO)
                return cached_data
        
        # Cache yoksa veya force refresh varsa API'den al
        url = "https://core-api.kablowebtv.com/api/channels"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
            "Referer": "https://tvheryerde.com",
            "Origin": "https://tvheryerde.com",
            "Cache-Control": "max-age=0",
            "Connection": "keep-alive",
            "Accept-Encoding": "gzip",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbnYiOiJMSVZFIiwiaXBiIjoiMCIsImNnZCI6IjA5M2Q3MjBhLTUwMmMtNDFlZC1hODBmLTJiODE2OTg0ZmI5NSIsImNzaCI6IlRSS1NUIiwiZGN0IjoiM0VGNzUiLCJkaSI6IjNkY2I2NmJiLTZhNjctNDIwYi1iN2MyLTg3ZGQ2MGFjNDNjZCIsInNnZCI6Ijk1N2U3NjliLWJiYjgtNGFiMC05NzYwLTgyM2UyMGE1OWFlMyIsInNwZ2QiOiIxNTY0ODUxZC1hY2ViLTQyZWUtYjkwZi04MGFlNTczOGEyM2EiLCJpY2giOiIwIiwiaWRtIjoiMCIsImlhIjoiOjpmZmZmOjEwLjAuMC42IiwiYXB2IjoiMS4wLjAiLCJhYm4iOiIxMDAwIiwibmJmIjoxNzQwOTY1ODI4LCJleHAiOjE3NDA5NjU4ODgsImlhdCI6MTc0MDk2NTgyOH0.8SgjsXtcwvmCYpV0W2T-rwwUiiFKpluz8crfpRhDv9A"
        }
        
        try:
            xbmc.log("CanliTV: API'den veri alınıyor...", xbmc.LOGINFO)
            
            # Kullanıcıya progress dialog göster
            progress = xbmcgui.DialogProgress()
            progress.create("CanliTV", "Kanallar yükleniyor...")
            progress.update(25, "API'ye bağlanılıyor...")
            
            if progress.iscanceled():
                progress.close()
                return None
            
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            
            progress.update(50, "Veri işleniyor...")
            
            # Gzip içeriği çözümle
            try:
                with gzip.GzipFile(fileobj=BytesIO(response.content)) as gz:
                    content = gz.read().decode('utf-8')
            except:
                content = response.content.decode('utf-8')
            
            progress.update(75, "Kanallar ayrıştırılıyor...")
            
            data = json.loads(content)
            
            if not data.get('IsSucceeded') or not data.get('Data', {}).get('AllChannels'):
                progress.close()
                xbmc.log("CanliTV: API'den geçerli veri alınamadı!", xbmc.LOGERROR)
                xbmcgui.Dialog().notification("CanliTV", "API'den veri alınamadı!", xbmcgui.NOTIFICATION_ERROR)
                return None
            
            channels = data['Data']['AllChannels']
            progress.update(90, "Cache'e kaydediliyor...")
            
            # Veriyi cache'e kaydet
            self._save_cache(channels)
            
            progress.update(100, "Tamamlandı!")
            progress.close()
            
            xbmc.log(f"CanliTV: {len(channels)} kanal API'den alındı ve cache'lendi", xbmc.LOGINFO)
            return channels
            
        except requests.exceptions.Timeout:
            if 'progress' in locals():
                progress.close()
            xbmc.log("CanliTV: API isteği zaman aşımına uğradı!", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("CanliTV", "Bağlantı zaman aşımı!", xbmcgui.NOTIFICATION_ERROR)
            # Timeout durumunda eski cache'i kullanmaya çalış
            return self._load_cache()
            
        except Exception as e:
            if 'progress' in locals():
                progress.close()
            xbmc.log(f"CanliTV Hata: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("CanliTV", f"Hata: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
            # Hata durumunda eski cache'i kullanmaya çalış
            return self._load_cache()
    
    def build_url(self, query):
        """URL parametrelerini oluştur"""
        return f"{self.url}?{urlencode(query)}"
    
    def _is_hls_stream(self, url):
        """URL'nin HLS stream olup olmadığını kontrol et"""
        if not url:
            return False
        
        # URL'yi küçük harfe çevir ve query parametrelerini temizle
        url_lower = url.lower()
        
        # HLS belirteçleri
        hls_indicators = [
            '.m3u8',           # Standart m3u8 uzantısı
            'm3u8',            # Query parametrelerinde m3u8
            'hls',             # HLS keyword
            'manifest.m3u8',   # Manifest dosyası
            'index.m3u8',      # Index dosyası
            'playlist.m3u8',   # Playlist dosyası
            'master.m3u8',     # Master playlist
            '/hls/',           # HLS path
            'hlsmanifest',     # HLS manifest keyword
            'application/x-mpegurl',  # MIME type (nadiren URL'de görülür)
        ]
        
        # Herhangi bir HLS belirteci varsa True döndür
        for indicator in hls_indicators:
            if indicator in url_lower:
                xbmc.log(f"CanliTV: HLS stream algılandı - {indicator} : {url}", xbmc.LOGDEBUG)
                return True
        
        # Ek kontroller - yaygın streaming servisleri
        streaming_services = [
            'wmsAuthSign',     # Wowza Media Server auth
            'token=',          # Token based streams
            'auth=',           # Auth parameter
            'sig=',            # Signature parameter
            'expires=',        # Expiring URLs
            'wmsd=',           # Wowza Media Server
        ]
        
        for service in streaming_services:
            if service in url_lower:
                xbmc.log(f"CanliTV: Streaming servisi algılandı (HLS varsayılan) - {service} : {url}", xbmc.LOGDEBUG)
                return True
        
        xbmc.log(f"CanliTV: HLS stream algılanamadı - {url}", xbmc.LOGDEBUG)
        return False
    
    def list_categories(self):
        """Kategorileri listele"""
        channels = self.get_channels()
        if not channels:
            return
        
        # Cache yenileme seçeneği ekle
        list_item = xbmcgui.ListItem(label="[COLOR yellow]>> Cache'i Yenile <<[/COLOR]")
        list_item.setInfo('video', {'plot': 'Kanal listesini API\'den yeniden yükle'})
        url = self.build_url({'action': 'refresh_cache'})
        xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        # Cache temizleme seçeneği ekle
        list_item = xbmcgui.ListItem(label="[COLOR red]>> Cache'i Temizle <<[/COLOR]")
        list_item.setInfo('video', {'plot': 'Kaydedilmiş cache\'i temizle'})
        url = self.build_url({'action': 'clear_cache'})
        xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        # Kategorileri topla
        categories = {}
        for channel in channels:
            channel_categories = channel.get('Categories', [])
            for cat in channel_categories:
                cat_name = cat.get('Name', 'Genel')
                if cat_name == "Bilgilendirme":
                    continue
                if cat_name not in categories:
                    categories[cat_name] = 0
                categories[cat_name] += 1
        
        # Tüm kanallar seçeneği
        list_item = xbmcgui.ListItem(label=f"[COLOR white][B]TUM KANALLAR ({len(channels)})[/B][/COLOR]")
        url = self.build_url({'action': 'list_channels', 'category': 'all'})
        xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        # Kategorileri ekle
        category_colors = {
            'Haber': 'red',
            'Spor': 'green', 
            'Eğlence': 'yellow',
            'Müzik': 'cyan',
            'Çocuk': 'pink',
            'Belgesel': 'orange',
            'Dizi': 'purple',
            'Film': 'blue',
            'Yaşam': 'lime',
            'Genel': 'white'
        }
        
        for cat_name, count in sorted(categories.items()):
            color = category_colors.get(cat_name, 'white')
            list_item = xbmcgui.ListItem(label=f"[COLOR {color}][B]{cat_name.upper()}[/B] ({count})[/COLOR]")
            url = self.build_url({'action': 'list_channels', 'category': cat_name})
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def list_channels(self, category=None):
        """Belirtilen kategorideki kanalları listele"""
        channels = self.get_channels()
        if not channels:
            return
        
        channel_count = 0
        for channel in channels:
            name = channel.get('Name')
            stream_data = channel.get('StreamData', {})
            hls_url = stream_data.get('HlsStreamUrl') if stream_data else None
            logo = channel.get('PrimaryLogoImageUrl', '')
            categories = channel.get('Categories', [])
            
            if not name or not hls_url:
                continue
            
            # Kategori filtresi
            if category and category != 'all':
                channel_in_category = False
                for cat in categories:
                    if cat.get('Name') == category:
                        channel_in_category = True
                        break
                if not channel_in_category:
                    continue
            
            # Bilgilendirme kategorisini atla
            skip_channel = False
            for cat in categories:
                if cat.get('Name') == "Bilgilendirme":
                    skip_channel = True
                    break
            if skip_channel:
                continue
            
            # Kanal öğesi oluştur
            list_item = xbmcgui.ListItem(label=name)
            list_item.setArt({'thumb': logo, 'icon': logo, 'fanart': logo})
            list_item.setInfo('video', {
                'title': name,
                'mediatype': 'video'
            })
            list_item.setProperty('IsPlayable', 'true')
            
            # InputStreamAdaptive özelliklerini ayarla - gelişmiş HLS algılama
            if self._is_hls_stream(hls_url):
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                # HLS için ek özellikler
                list_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36&Referer=https://tvheryerde.com')
                list_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                list_item.setContentLookup(False)
            
            url = self.build_url({'action': 'play', 'url': hls_url, 'name': name})
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, False)
            channel_count += 1
        
        xbmc.log(f"CanliTV: {channel_count} kanal listelendi", xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(self.handle)
    
    def play_channel(self, url, name):
        """Kanalı oynat"""
        try:
            play_item = xbmcgui.ListItem(label=name, path=url)
            play_item.setInfo('video', {'title': name, 'mediatype': 'video'})
            
            # InputStreamAdaptive ayarları - gelişmiş HLS algılama
            if self._is_hls_stream(url):
                play_item.setProperty('inputstream', 'inputstream.adaptive')
                play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                # Stream başlıkları
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
                    'Referer': 'https://tvheryerde.com',
                    'Origin': 'https://tvheryerde.com'
                }
                header_string = '&'.join([f"{k}={v}" for k, v in headers.items()])
                play_item.setProperty('inputstream.adaptive.stream_headers', header_string)
                play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                play_item.setContentLookup(False)
                
                # Oynatma kalitesi ayarları (opsiyonel)
                quality_setting = self.addon.getSetting('quality')
                if quality_setting == '1':  # 720p
                    play_item.setProperty('inputstream.adaptive.max_bandwidth', '3000000')
                elif quality_setting == '2':  # 480p
                    play_item.setProperty('inputstream.adaptive.max_bandwidth', '1500000')
                elif quality_setting == '3':  # 360p
                    play_item.setProperty('inputstream.adaptive.max_bandwidth', '800000')
            
            xbmcplugin.setResolvedUrl(self.handle, True, listitem=play_item)
            xbmc.log(f"CanliTV: {name} kanalı oynatılıyor - {url}", xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log(f"CanliTV Oynatma Hatası: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("CanliTV", f"Oynatma hatası: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def refresh_cache(self):
        """Cache'i yenile"""
        try:
            # Önce eski cache'i sil
            self._clear_cache()
            
            # Yeni veriyi al (force refresh)
            channels = self.get_channels(force_refresh=True)
            
            if channels:
                xbmcgui.Dialog().notification("CanliTV", f"Cache yenilendi! ({len(channels)} kanal)", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification("CanliTV", "Cache yenilenemedi!", xbmcgui.NOTIFICATION_ERROR)
                
            # Ana menüye dön
            xbmc.executebuiltin(f'Container.Update({self.url})')
            
        except Exception as e:
            xbmc.log(f"CanliTV Cache Yenileme Hatası: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("CanliTV", f"Cache yenileme hatası!", xbmcgui.NOTIFICATION_ERROR)
    
    def clear_cache_menu(self):
        """Cache temizleme menüsü"""
        try:
            # Onay iste
            dialog = xbmcgui.Dialog()
            if dialog.yesno("CanliTV", "Cache'i temizlemek istediğinizden emin misiniz?", 
                          "Bu işlem kaydedilmiş tüm kanal verilerini silecek."):
                
                success = self._clear_cache()
                if success:
                    dialog.notification("CanliTV", "Cache temizlendi!", xbmcgui.NOTIFICATION_INFO)
                else:
                    dialog.notification("CanliTV", "Cache temizlenemedi!", xbmcgui.NOTIFICATION_ERROR)
                
                # Ana menüye dön
                xbmc.executebuiltin(f'Container.Update({self.url})')
                
        except Exception as e:
            xbmc.log(f"CanliTV Cache Temizleme Menü Hatası: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("CanliTV", "İşlem hatası!", xbmcgui.NOTIFICATION_ERROR)
    
    def router(self, paramstring):
        """URL parametrelerini işle ve uygun fonksiyonu çağır"""
        params = dict(parse_qsl(paramstring))
        
        if params:
            action = params.get('action')
            
            if action == 'list_channels':
                category = params.get('category')
                self.list_channels(category)
            elif action == 'play':
                url = params.get('url')
                name = params.get('name')
                self.play_channel(url, name)
            elif action == 'refresh_cache':
                self.refresh_cache()
            elif action == 'clear_cache':
                self.clear_cache_menu()
        else:
            # Ana menü - kategorileri listele
            self.list_categories()

def main():
    """Ana fonksiyon"""
    addon_instance = CanliTVAddon()
    addon_instance.router(sys.argv[2][1:])  # İlk karakteri (?) kaldır

if __name__ == '__main__':
    main()