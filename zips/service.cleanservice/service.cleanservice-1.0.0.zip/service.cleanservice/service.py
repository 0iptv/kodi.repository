# -*- coding: utf-8 -*-
"""
This script runs as a background service for the Clean Service addon.

It periodically checks for and cleans cache files, packages, and other temporary
data based on the rules and schedule defined in the addon's settings.
The service can be enabled/disabled and configured via the addon settings.
"""
import xbmc
import xbmcaddon
import time
from fileManager import (
    DeleteCoreFiles,
    PurgePackages,
    ClearUserThumbnails,
    calculate_directory_size,
    ClearAllThumbnails,
    clearAllCaches,
)

# Global flag to track the first execution of the cleanup task in a session
is_first_run = True

def run_cleanup(show_notification=False):
    """
    Executes the main cleaning logic based on the addon's settings.

    This function is called periodically by the service. It reads the cleaning
    rules (cache size limits, auto-clean options) from the settings and runs
    the corresponding cleaning tasks from fileManager. Logs the result.

    Args:
        show_notification (bool): If True, a notification will be shown to the
                                  user upon completion.
    """
    addon = xbmcaddon.Addon()
    setting = addon.getSetting

    total_files, total_folders, total_size = 0, 0, 0

    # Read cleaning settings from settings.xml
    try:
        size_limit = int(setting("filesize_alert")) * 1024 * 1024
    except (ValueError, TypeError):
        size_limit = 500 * 1024 * 1024  # Default 500MB

    try:
        thumb_size_limit = int(setting("filesizethumb_alert")) * 1024 * 1024
    except (ValueError, TypeError):
        thumb_size_limit = 500 * 1024 * 1024  # Default 500MB

    autoclean = setting("autoclean") == "true"

    # --- Start Cleaning Tasks ---

    # Clean Kodi crash logs (core files)
    files0, folders0, size0 = DeleteCoreFiles.remoteFolderAndFiles()
    total_files += files0
    total_folders += folders0
    total_size += size0

    # Clean addon packages if cache size exceeds the limit
    if calculate_directory_size(PurgePackages.path) > size_limit:
        files1, folders1, size1 = PurgePackages.remoteFolderAndFiles()
        total_files += files1
        total_folders += folders1
        total_size += size1

    # Clean thumbnails if cache size exceeds the limit
    if calculate_directory_size(ClearUserThumbnails.path) > thumb_size_limit:
        files2, folders2, size2 = ClearAllThumbnails()
        total_files += files2
        total_folders += folders2
        total_size += size2

    # If auto-clean is enabled in settings, clean all general caches
    if autoclean:
        files3, folders3, size3 = clearAllCaches()
        total_files += files3
        total_folders += folders3
        total_size += size3

    # --- Log and Notify ---
    
    # Log the result to the kodi.log file if a cleanup was performed.
    if total_files > 0 or total_folders > 0 or total_size > 0:
        log_message = (
            f"Otomatik temizlik tamamlandı. {total_files} dosya ve {total_folders} klasör silindi. "
            f"Toplam boyut: {round(total_size/(1024 * 1024), 2)} MB"
        )
        xbmc.log(f"Clean Service: {log_message}", level=xbmc.LOGINFO)
    
    # If requested, show a notification regardless of whether cleanup occurred.
    if show_notification:
        import xbmcgui
        if total_files > 0 or total_folders > 0 or total_size > 0:
            # If something was cleaned, use the detailed log message.
            message = (
                f"Otomatik temizlik tamamlandı. {total_files} dosya ve {total_folders} klasör silindi. "
                f"Toplam boyut: {round(total_size/(1024 * 1024), 2)} MB"
            )
        else:
            # If nothing was cleaned, show a different message.
            message = "Temizlenecek bir şey bulunamadı."
        
        xbmcgui.Dialog().notification('Clean Service', message, xbmcgui.NOTIFICATION_INFO, 5000, sound=False)


if __name__ == "__main__":
    """
    Main entry point for the service.
    Initializes the addon and starts the service loop.
    """
    addon = xbmcaddon.Addon()
    addon_name = addon.getAddonInfo("name")
    monitor = xbmc.Monitor()

    xbmc.log(f"{addon_name}: Service started", level=xbmc.LOGINFO)

    # Main service loop
    while not monitor.abortRequested():
        # Read settings inside the loop to ensure the service reacts to changes.
        service_enabled = addon.getSetting("service_enable") == "true"

        # If service is disabled in settings, wait and check again later.
        if not service_enabled:
            if monitor.waitForAbort(60):  # Check every minute if service gets enabled
                break
            continue

        # Get the cleaning interval from settings.
        try:
            clean_interval_minutes = int(addon.getSetting("clean_interval"))
        except (ValueError, TypeError):
            clean_interval_minutes = 60  # Default to 60 minutes

        # Run the cleanup. Show notification only on the first run of the session.
        run_cleanup(show_notification=is_first_run)

        # After the first run, set the flag to False to disable future notifications.
        if is_first_run:
            is_first_run = False

        # Wait for the specified interval before the next run.
        # waitForAbort returns true if Kodi is shutting down.
        if monitor.waitForAbort(clean_interval_minutes * 60):
            break  # Exit the loop if Kodi is shutting down.

    xbmc.log(f"{addon_name}: Service stopped", level=xbmc.LOGINFO)