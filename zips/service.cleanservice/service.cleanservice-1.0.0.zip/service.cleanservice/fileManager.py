# -*- coding: utf-8 -*-
"""
This module provides a framework for cleaning various cache and temporary
directories within Kodi.

It defines an abstract base class `FileManager` and several concrete
implementations for specific cleaning tasks, such as clearing core dump files,
addon packages, thumbnails, and various other cache locations.
"""
import os
import shutil
from abc import ABC, abstractmethod
from typing import Tuple
import xbmc      # type: ignore
import xbmcvfs   # type: ignore


class FileManager(ABC):
    """
    Abstract base class for a file and folder cleaning utility.

    Subclasses must define a `path` and implement the `checkerFiles` and
    `checkerFolders` methods to specify which items to delete.
    """
    # --- Configuration for subclasses ---
    isActiveFolderRemoves = False
    isActiveFileRemoves = False
    path = None

    @classmethod
    def remoteFolderAndFiles(cls) -> Tuple[int, int, int]:
        """
        Removes folders and files from the specified `cls.path` based on checker methods.

        It iterates through items in the path, checks them against `checkerFiles`
        and `checkerFolders`, and then removes them.

        NOTE: The actual deletion lines (`os.unlink`, `shutil.rmtree`) are
        commented out by default. To enable deletion, uncomment those lines.

        Returns:
            Tuple[int, int, int]: A tuple containing the total number of files deleted,
                                  folders deleted, and their combined size in bytes.
        """
        if cls.path is None:
            xbmc.log(f'[{cls.__name__}] Path is not set', xbmc.LOGERROR)
            return 0, 0, 0
        if not os.path.exists(cls.path):
            xbmc.log(f'[{cls.__name__}] Path {cls.path} does not exist', xbmc.LOGERROR)
            return 0, 0, 0
            
        total_files = 0
        total_folders = 0
        total_size = 0

        try:
            # List all items in the target directory
            items = os.listdir(cls.path)
            
            # Process files for deletion
            if cls.isActiveFileRemoves:
                for item in items:
                    item_path = os.path.join(cls.path, item)
                    if os.path.isfile(item_path):
                        try:
                            # Check if the file should be deleted
                            if cls.checkerFiles(item):
                                size = os.path.getsize(item_path)
                                # Deletion is active
                                os.unlink(item_path)
                                xbmc.log(f'[{cls.__name__}] Deleted file: {item_path} ({size / (1024 * 1024):.2f} MB)', xbmc.LOGDEBUG)
                                total_size += size
                                total_files += 1
                        except (OSError, IOError, PermissionError) as e:
                            xbmc.log(f'[{cls.__name__}] Failed to process file {item}: {str(e)}', xbmc.LOGERROR)

            # Process folders for deletion
            if cls.isActiveFolderRemoves:
                for item in items:
                    item_path = os.path.join(cls.path, item)
                    if os.path.isdir(item_path):
                        try:
                            # Check if the folder should be deleted
                            if cls.checkerFolders(item):
                                size = calculate_directory_size(item_path)
                                # Deletion is active
                                shutil.rmtree(item_path)
                                xbmc.log(f'[{cls.__name__}] Deleted folder: {item_path} ({size / (1024 * 1024):.2f} MB)', xbmc.LOGDEBUG)
                                total_size += size
                                total_folders += 1
                        except (OSError, IOError, PermissionError) as e:
                            xbmc.log(f'[{cls.__name__}] Failed to process folder {item}: {str(e)}', xbmc.LOGERROR)

        except Exception as e:
            xbmc.log(f'[{cls.__name__}] Error processing directory {cls.path}: {str(e)}', xbmc.LOGERROR)

        total_mb = total_size / (1024 * 1024)
        xbmc.log(
            f'[{cls.__name__}] Cleanup stats: Total files: {total_files}, '
            f'Total directories: {total_folders}, Total size: {total_mb:.2f} MB',
            xbmc.LOGINFO
        )
        return total_files, total_folders, total_size

    @staticmethod
    @abstractmethod
    def checkerFiles(file: str) -> bool:
        """
        Abstract method to check if a file should be deleted.
        Must be implemented by subclasses.

        Args:
            file (str): The name of the file to check.

        Returns:
            bool: True if the file should be deleted, False otherwise.
        """

    @staticmethod
    @abstractmethod
    def checkerFolders(folder: str) -> bool:
        """
        Abstract method to check if a folder should be deleted.
        Must be implemented by subclasses.

        Args:
            folder (str): The name of the folder to check.

        Returns:
            bool: True if the folder should be deleted, False otherwise.
        """

# --- Concrete Cleaner Implementations ---

class DeleteCoreFiles(FileManager):
    """Cleans core dump files (e.g., crash logs) from the Kodi root directory."""
    isActiveFolderRemoves = False
    isActiveFileRemoves = True
    path = xbmcvfs.translatePath('special://xbmc')
    
    @staticmethod
    def checkerFiles(file: str) -> bool:
        return file.startswith("core.")

    @staticmethod
    def checkerFolders(folder: str) -> bool:
        return False


class PurgePackages(FileManager):
    """Cleans all files and folders from the addon packages directory."""
    isActiveFolderRemoves = True
    isActiveFileRemoves = True
    path = xbmcvfs.translatePath('special://home/addons/packages')
    
    @staticmethod
    def checkerFiles(file: str) -> bool:
        return True

    @staticmethod
    def checkerFolders(folder: str) -> bool:
        return True


class ClearCache(FileManager):
    """Cleans all files and folders from the main Kodi cache directory."""
    isActiveFolderRemoves = True
    isActiveFileRemoves = True
    path = xbmcvfs.translatePath('special://home/cache')
    
    @staticmethod
    def checkerFiles(file: str) -> bool:
        return True

    @staticmethod
    def checkerFolders(folder: str) -> bool:
        return True


class ClearTemp(ClearCache):
    """Cleans files from the temp directory, excluding log files."""
    path = xbmcvfs.translatePath('special://home/temp')
    
    @staticmethod
    def checkerFiles(file: str) -> bool:
        # Do not delete log files
        return not file.endswith('.log')


class ClearAddonsTemp(ClearCache):
    """Cleans all files and folders from the addons temp directory."""
    path = xbmcvfs.translatePath('special://home/addons/temp')


class CommonCleaner(ClearCache):
    """A generic cleaner used for a list of common addon data folders."""
    path = None


class ClearThumbnails(FileManager):
    """Cleans all files from the main thumbnails directory."""
    path = xbmcvfs.translatePath('special://thumbnails')
    isActiveFolderRemoves = False
    isActiveFileRemoves = True
    
    @staticmethod
    def checkerFiles(file: str) -> bool:
        return True

    @staticmethod
    def checkerFolders(folder: str) -> bool:
        return False


class ClearUserThumbnails(ClearThumbnails):
    """Cleans all files from the user-specific thumbnails directory."""
    path = xbmcvfs.translatePath('special://home/userdata/Thumbnails')
    

# --- Helper Functions ---

def ClearAllThumbnails() -> Tuple[int, int, int]:
    """
    Clears both the main and user-specific thumbnail caches and the Textures database.

    Returns:
        Tuple[int, int, int]: Total files, folders, and size deleted.
    """
    total_files, total_folders, total_size = 0, 0, 0
    
    # Clean standard and user thumbnail folders
    ctfiles, ctfolders, ctsize = ClearThumbnails.remoteFolderAndFiles()
    total_files += ctfiles
    total_folders += ctfolders
    total_size += ctsize
    
    cutfiles, cutfolders, cutsize = ClearUserThumbnails.remoteFolderAndFiles()
    total_files += cutfiles
    total_folders += cutfolders
    total_size += cutsize
    
    # Delete the texture database
    try:
        text13_path = xbmcvfs.translatePath("special://database/Textures13.db")
        if os.path.exists(text13_path):
            size = os.path.getsize(text13_path)
            os.unlink(text13_path)
            xbmc.log(f'[{ClearAllThumbnails.__name__}] Deleted file: {text13_path} ({size / (1024 * 1024):.2f} MB)', xbmc.LOGINFO)
            total_files += 1
            total_size += size
    except (OSError, IOError, PermissionError) as e:
        xbmc.log(f'[{ClearAllThumbnails.__name__}] Failed to delete Textures13.db: {str(e)}', xbmc.LOGERROR)
        
    return total_files, total_folders, total_size


def clear_common_entries() -> Tuple[int, int, int]:
    """
    Clears a predefined list of common cache folders used by popular addons.

    Returns:
        Tuple[int, int, int]: Total files, folders, and size deleted.
    """
    total_files, total_folders, total_size = 0, 0, 0
    
    # A dictionary mapping addon-specific cache paths to friendly names for logging.
    # This is safer and more readable than using two separate lists.
    common_paths = {
        "special://profile/addon_data/plugin.video.youtube/kodion": "YouTube",
        "special://profile/addon_data/script.module.urlresolve/cache": "UrlResolve",
        "special://profile/addon_data/script.module.simplecache": "Simple Cacher",
        "special://profile/addon_data/script.module.simple.downloader": "Simple Downloader",
        "special://profile/addon_data/script.module.metadatautils/animatedgifs": "Metadatautils",
        "special://profile/addon_data/script.module.streamlink/base": "Streamlink",
        "special://profile/addon_data/plugin.video.tvalacarta/downloads": "Tvalacarta",
        "special://profile/addon_data/script.module.resolveurl/cache": "Resolveurl",
        "special://profile/addon_data/plugin.video.alfa/downloads": "Alfa Downloads",
        "special://profile/addon_data/script.module.metahandler/meta_cache": "Metahandler",
        "special://profile/addon_data/script.module.youtube.dl/tmp": "Youtube.dl",
        "special://profile/addon_data/script.extendedinfo/images": "Extendedinfo",
        "special://profile/addon_data/script.extendedinfo/TheMovieDB": "TheMovieDB",
        "special://profile/addon_data/script.extendedinfo/YouTube": "Extendedinfo/YouTube",
        "special://profile/addon_data/plugin.program.autocompletion/Google": "Autocompletion/Google",
        "special://profile/addon_data/plugin.program.autocompletion/Bing": "Autocompletion/Bing",
        "special://profile/addon_data/script.module.universalscrapers": "Universalscrapers",
        "special://profile/addon_data/plugin.video.alfa/videolibrary/temp_torrents_Alfa": "Torrents Alfa",
        "special://profile/addon_data/plugin.video.mediaexplorer/downloads": "MediaExplorer Downloads",
        "special://profile/addon_data/plugin.video.balandro/downloads": "Balandro Downloads",
        "special://profile/addon_data/plugin.video.mediaexplorer/torrent": "MediaExplorer Torrent"
    }
    
    for path, name in common_paths.items():
        CommonCleaner.path = xbmcvfs.translatePath(path)
        files, folders, size = CommonCleaner.remoteFolderAndFiles()
        total_files += files
        total_folders += folders
        total_size += size
        xbmc.log(
            f'[{CommonCleaner.__name__}] Path: {path}, '
            f'Dialog: {name}, Total files: {files}, '
            f'Total directories: {folders}, Total size: {size / (1024*1024):.2f} MB',
            xbmc.LOGDEBUG
        )
    return total_files, total_folders, total_size


def clearAllCaches() -> Tuple[int, int, int]:
    """
    Runs a comprehensive cache cleaning process.

    This combines cleaning of the main cache, temp folders, and common
    addon-specific cache folders.

    Returns:
        Tuple[int, int, int]: Total files, folders, and size deleted.
    """
    total_files, total_folders, total_size = 0, 0, 0
    
    # Run individual cleaning functions and aggregate the results
    files1, folders1, size1 = ClearCache.remoteFolderAndFiles()
    files2, folders2, size2 = ClearTemp.remoteFolderAndFiles()
    files3, folders3, size3 = ClearAddonsTemp.remoteFolderAndFiles()
    files4, folders4, size4 = clear_common_entries()
    
    total_files = files1 + files2 + files3 + files4
    total_folders = folders1 + folders2 + folders3 + folders4
    total_size = size1 + size2 + size3 + size4
    
    return total_files, total_folders, total_size


def calculate_directory_size(directory_path: str) -> int:
    """
    Calculates the total size of a directory in bytes.

    Args:
        directory_path (str): The path to the directory.

    Returns:
        int: The total size of the directory in bytes.
    """
    total_size = 0
    if not os.path.exists(directory_path):
        return 0
    for dirpath, dirnames, filenames in os.walk(directory_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            # Check if it's a symlink and if the path exists
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)
    return total_size