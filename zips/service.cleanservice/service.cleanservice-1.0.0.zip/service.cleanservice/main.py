# -*- coding: utf-8 -*-
"""
This script serves as the user-facing application part of the Clean Service addon.
It provides a menu to allow users to trigger specific cleaning tasks manually,
run a full cleanup, or open the addon's settings dialog.
"""
import xbmcaddon
import xbmcgui
from fileManager import (
    DeleteCoreFiles,
    PurgePackages,
    ClearUserThumbnails,
    calculate_directory_size,
    ClearAllThumbnails,
    clearAllCaches
)

# --- Helper Function ---

def _show_notification(files=0, folders=0, size=0):
    """
    Displays a notification to the user with the cleaning results.

    Args:
        files (int): Number of files deleted.
        folders (int): Number of folders deleted.
        size (int): Total size of deleted items in bytes.
    """
    if files > 0 or folders > 0 or size > 0:
        message = (
            f'Toplam {files} dosya ve {folders} klasör silindi, '
            f'toplam boyut {round(size / (1024 * 1024), 2)} MB'
        )
        xbmcgui.Dialog().notification('Clean Service', message, xbmcgui.NOTIFICATION_INFO, 5000)
    else:
        xbmcgui.Dialog().notification('Clean Service', 'Temizlenecek bir şey bulunamadı.', xbmcgui.NOTIFICATION_INFO, 5000)

# --- Individual Cleaning Functions ---

def cleanup_core():
    """Cleans Kodi crash logs (core dump files)."""
    files, folders, size = DeleteCoreFiles.remoteFolderAndFiles()
    _show_notification(files, folders, size)

def cleanup_packages():
    """Cleans the addon packages directory."""
    files, folders, size = PurgePackages.remoteFolderAndFiles()
    _show_notification(files, folders, size)

def cleanup_thumbnails():
    """Cleans all thumbnail caches and the texture database."""
    files, folders, size = ClearAllThumbnails()
    _show_notification(files, folders, size)

def cleanup_caches():
    """Performs a comprehensive cleaning of all general cache folders."""
    files, folders, size = clearAllCaches()
    _show_notification(files, folders, size)

def cleanup_all():
    """
    Executes a full cleanup of all available categories.

    This function runs all individual cleaning tasks sequentially and reports
    the aggregated result to the user.
    """
    total_files, total_folders, total_size = 0, 0, 0

    # Clean Kodi crash logs (core files)
    files, folders, size = DeleteCoreFiles.remoteFolderAndFiles()
    total_files += files
    total_folders += folders
    total_size += size

    # Clean addon packages
    files, folders, size = PurgePackages.remoteFolderAndFiles()
    total_files += files
    total_folders += folders
    total_size += size

    # Clean thumbnails
    files, folders, size = ClearAllThumbnails()
    total_files += files
    total_folders += folders
    total_size += size

    # Clean all general caches
    files, folders, size = clearAllCaches()
    total_files += files
    total_folders += folders
    total_size += size
    
    # Report final results
    _show_notification(total_files, total_folders, total_size)


# --- Main Execution Block ---

if __name__ == "__main__":
    """
    Main entry point for the script.
    Displays a multi-level dialog menu to the user for granular control.
    """
    addon = xbmcaddon.Addon()
    dialog = xbmcgui.Dialog()
    
    # Main menu
    main_menu_items = [
        "Parça Parça Temizle...",
        "Tümünü Kapsamlı Temizle",
        "Ayarlar"
    ]
    main_choice = dialog.select("Clean Service", main_menu_items)

    # Sub-menu for specific cleaning tasks
    if main_choice == 0:
        sub_menu_items = [
            "Çökme Raporlarını Temizle (Core Dumps)",
            "Eklenti Paketlerini Temizle (Packages)",
            "Önizleme Resimlerini Temizle (Thumbnails)",
            "Tüm Genel Önbellekleri Temizle (Cache)"
        ]
        sub_choice = dialog.select("Parça Parça Temizle", sub_menu_items)

        if sub_choice == 0:
            cleanup_core()
        elif sub_choice == 1:
            cleanup_packages()
        elif sub_choice == 2:
            cleanup_thumbnails()
        elif sub_choice == 3:
            cleanup_caches()

    # Full cleanup
    elif main_choice == 1:
        cleanup_all()

    # Open settings
    elif main_choice == 2:
        addon.openSettings()

    # User cancelled or closed the dialog
    else:
        pass
