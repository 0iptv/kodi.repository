from dataclasses import dataclass
from typing import Union

from model.component import OtherComponent, SoupComponent

@dataclass
class CategoryItem:
    """Docstring for Category_Item."""

    name: str
    url: str
    is_paging: bool
    headers: dict[str, str]
    component: Union[OtherComponent, SoupComponent, None]
