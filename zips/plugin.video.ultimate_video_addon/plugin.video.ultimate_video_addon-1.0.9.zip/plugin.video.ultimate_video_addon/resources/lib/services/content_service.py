from typing import Callable, Dict, List, Optional, Union

from model.chapter import Chapter
from model.category import CategoryItem
from model.component import OtherComponent, SoupComponent
from model.media import Media
from model.movie import Movie
from model.serie import Serie
from model.video_content import ContentType, ListContent
from integrations import api_connector
from utils.parser import Parser


def get_category(category: CategoryItem, page_number=1) -> Optional[List[ListContent]]:
    """
    Fetches the content for a given category.
    """
    url = category.url
    if category.is_paging:
        url = url.format(page=page_number)

    html_content = api_connector.make_request(url, category.headers)
    if not html_content or not category.component:
        return None
    return Parser.parse_category(html_content, category.component)


def _get_movie_details(
    html_content: str, component: Union[OtherComponent, SoupComponent]
) -> Optional[Movie]:
    """
    Parses the details for a given movie from html_content.
    """
    if not html_content:
        return None
    return Parser.parse_movie(html_content, component)


def _get_chapter_details(
    html_content: str, component: Union[OtherComponent, SoupComponent]
) -> Optional[Chapter]:
    """
    Parses the details for a given movie from html_content.
    """
    if not html_content:
        return None
    return Parser.parse_chapter(html_content, component)


def _get_serie_details(
    html_content: str, component: Union[OtherComponent, SoupComponent]
) -> Optional[Serie]:
    """
    Parses the details for a given series from html_content.
    """
    if not html_content:
        return None
    return Parser.parse_serie(html_content, component)


def load(
    url: str,
    headers: dict,
    movie_component: Union[OtherComponent, SoupComponent],
    serie_component: Union[OtherComponent, SoupComponent],
    chapter_component: Union[OtherComponent, SoupComponent],
    type_check_func: Callable[[str], Optional[ContentType]],
) -> Optional[Union[Movie, Serie, Chapter]]:
    """
    Generic load function to fetch and parse content based on its type.
    """
    html_content = api_connector.make_request(url, headers)
    if not html_content:
        return None

    content_type = type_check_func(html_content)

    if content_type == ContentType.SERIE:
        return _get_serie_details(html_content, serie_component)
    if content_type == ContentType.MOVIE:
        return _get_movie_details(html_content, movie_component)
    if content_type == ContentType.CHAPTER:
        return _get_chapter_details(html_content, chapter_component)
    return None


def search(url: str, headers: Dict[str, str], search_component):
    """_summary_

    Args:
        url (str): _description_
        headers (Dict[str,str]): _description_
    """
    json_content = api_connector.make_request(url, headers)
    if not json_content:
        return None
    results = json_content.get("results", None)
    if not results:
        return None
    if isinstance(results, list):
        html_content = " ".join(map(str, results))
        return Parser.parse_category(html_content, search_component)
    return None
