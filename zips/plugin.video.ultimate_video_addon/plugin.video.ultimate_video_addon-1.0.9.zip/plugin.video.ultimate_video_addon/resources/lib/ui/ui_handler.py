import os
import re
import urllib.parse
from api.tmdb import tmdb_search, get_tmdb_genres
import xbmc  # type: ignore
import xbmcgui  # type: ignore
import xbmcplugin  # type: ignore
import xbmcaddon  # type: ignore
from routing import Plugin
from typing import Optional
from model.chapter import Chapter
from model.media import Media
from model.movie import Movie
from model.serie import Serie
from core import constants
from ui import router


class UIHandler:
    plugin: Optional[Plugin] = None

    @staticmethod
    def create_provider_home(provider_id: str):
        """Creates the directory items for the home page."""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        # Add a static link to search
        li = xbmcgui.ListItem(label="Search")
        xbmcplugin.addDirectoryItem(
            handle=UIHandler.plugin.handle,
            url=UIHandler.plugin.url_for(router.search, provider_id),
            listitem=li,
            isFolder=True,
        )
        for [category_id, category] in provider.CATEGORIES.items():
            li = xbmcgui.ListItem(label=category.name)
            path = xbmcaddon.Addon().getAddonInfo("path")
            li.setArt({"poster": os.path.join(path, "resources", "media", "category.png")})
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(router.category, provider_id, category_id, 1),
                listitem=li,
                isFolder=True,
            )
        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def create_providers():
        """Creates the directory items for the home page."""

        if not UIHandler.plugin:
            return

        for provider_id, provider in constants.PROVIDERS.items():
            li = xbmcgui.ListItem(label=provider.NAME)
            if provider.ICON:
                path = xbmcaddon.Addon().getAddonInfo("path")
                li.setArt({"poster": os.path.join(path, "resources", "media", f"{provider.ICON}")})
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(router.provider, provider_id),
                listitem=li,
                isFolder=True,
            )
        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def category(provider_id: str, category_id: str, page_number=1):
        """Create the list screen UI for a given category"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        category = provider.CATEGORIES.get(category_id, None)
        if not category:
            return
        result_list = provider.Category(category_id, page_number)
        if not result_list:
            return
        page_number = int(page_number)
        if page_number > 1 and category.is_paging:
            li = xbmcgui.ListItem(label="PREVIOUS")
            path = xbmcaddon.Addon().getAddonInfo("path")
            li.setArt({"poster": os.path.join(path, "resources", "media", "category.png")})
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(router.category, provider_id, category_id, page_number - 1),
                listitem=li,
                isFolder=True,
            )
        for item in result_list:
            url = item.url
            referer = category.headers.get("referer", f"https://{provider.OPTIONS.DOMAIN}/")
            if not url:
                return
            li = xbmcgui.ListItem(label=item.title)
            tmdb_json = tmdb_search(item.title)

            if tmdb_json and tmdb_json.get("results"):
                result = tmdb_json["results"][0]
                media_type = result.get("media_type")

                info = {"plot": result.get("overview"), "rating": result.get("vote_average")}
                art = {}

                genre_ids = result.get("genre_ids")
                if genre_ids and media_type:
                    info["genre"] = get_tmdb_genres(genre_ids, media_type)

                poster_path = result.get("poster_path")
                if poster_path:
                    art["poster"] = f"https://image.tmdb.org/t/p/w500{poster_path}"
                else:
                    art["poster"] = item.image

                backdrop_path = result.get("backdrop_path")
                if backdrop_path:
                    art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"

                if media_type == "movie":
                    info["title"] = result.get("title", item.title)
                    release_date = result.get("release_date")
                    if release_date:
                        info["premiered"] = release_date
                        if release_date.split("-"):
                            info["year"] = int(release_date.split("-")[0])
                    info["mediatype"] = "movie"
                elif media_type == "tv":
                    info["title"] = result.get("name", item.title)
                    first_air_date = result.get("first_air_date")
                    if first_air_date:
                        info["premiered"] = first_air_date
                        if first_air_date.split("-"):
                            info["year"] = int(first_air_date.split("-")[0])
                    info["mediatype"] = "tvshow"
                    info["tvshowtitle"] = info["title"]

                if "year" not in info and item.year:
                    try:
                        info["year"] = int(item.year)
                    except (ValueError, TypeError):
                        pass

                li.setArt(art)
                li.setInfo("video", info)
            else:
                li.setArt({"poster": item.image})
                info = {"title": item.title, "season": item.title, "mediatype": "season", "tvshowtitle": item.title}
                try:
                    if item.year:
                        info["year"] = int(item.year)
                except (ValueError, TypeError):
                    pass
                try:
                    if item.rating:
                        info["rating"] = float(item.rating)
                except (ValueError, TypeError):
                    pass
                li.setInfo("video", info)
            if item.type=="serie":
                isfolder=True  # Serie için folder true yapıyoruz
                li.setProperty('IsPlayable', 'false')  # Playable false olmalı
            else:
                li.setProperty('IsPlayable', 'true')
                isfolder=False
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(
                    router.load, provider_id, urllib.parse.quote(url, safe=""), urllib.parse.quote(referer, safe="")
                ),
                listitem=li,
                isFolder=isfolder,
            )

        if category.is_paging:
            li = xbmcgui.ListItem(label="NEXT")
            path = xbmcaddon.Addon().getAddonInfo("path")
            li.setArt({"poster": os.path.join(path, "resources", "media", "category.png")})
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(router.category, provider_id, category_id, page_number + 1),
                listitem=li,
                isFolder=True,
            )
        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def load(provider_id: str, content_url: str, referer: str):
        """Create the list screen UI for a given list"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        result = provider.load(content_url, referer)
        if not result:
            return
        if isinstance(result, Serie):            
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            if result.trailer:
                referer = content_url
                li = xbmcgui.ListItem(label="Trailer")
                li.setArt({"poster": result.image})
                li.setProperty('IsPlayable', 'true')
                li.setInfo(
                    "video",
                    {
                        "title": result.title +" - Trailer",
                        "mediatype": "trailer",
                        "genre": result.genres,
                        "plot": result.plot,
                    },
                )
                item_url=UIHandler.plugin.url_for(
                        router.trailer, 
                        provider_id, 
                        urllib.parse.quote(result.trailer, safe=""), 
                        urllib.parse.quote(referer, safe="")
                    )
                playlist.add(item_url, li)  
                
                
            for index, item in enumerate(result.chapters, start=1):
                serie_url = item.url
                referer = content_url
                
                li = xbmcgui.ListItem(label=item.title)
                li.setArt({"poster": result.image})                
                li.setProperty('IsPlayable', 'true')
                try:
                    year = int(result.year)
                except:
                    year = 0
                    
                try:
                    rating = float(result.rating)
                except:
                    rating = 0.0
                match = re.search(r'(\d+)[^\d]*(\d+)', item.title)
                if match:
                    season=match.group(1)
                    episode=match.group(2)
                li.setInfo(
                    "video",
                    {
                        "title": result.title,
                        "season": int(season) if season.isdigit() else -1,
                        "episode": int(episode) if episode.isdigit() else index,
                        "mediatype": "episode",
                        "genre": result.genres,
                        "year": year,
                        "plot": result.plot,
                        "rating": rating,
                        "tvshowtitle": item.title,
                    },
                )
                item_url=UIHandler.plugin.url_for(
                        router.load,
                        provider_id,
                        urllib.parse.quote(serie_url, safe=""),
                        urllib.parse.quote(referer, safe=""),
                    )
                
                playlist.add(item_url, li)
            xbmc.executebuiltin('Dialog.Close(all)')  # Mevcut pencereleri kapat
            xbmc.executebuiltin('ActivateWindow(VideoPlaylist)') # Playlist penceresini aç

        elif isinstance(result, Movie) or isinstance(result, Chapter):
            referer = content_url
            
            if isinstance(result, Movie) and result.trailer:                
                if not result.sources or len(result.sources) == 0:
                    selected_source = result.trailer
                else:
                    source_labels =["Trailer"] + [f"Source {i + 1}" for i, _ in enumerate(result.sources)]                    
                    dialog = xbmcgui.Dialog()
                    selected_index = dialog.select("Select a source", source_labels)
                    if selected_index == -1:
                        selected_source = result.sources[0]
                        UIHandler.play(provider_id, selected_source, referer)
                    elif selected_index == 0:
                        selected_source = result.trailer
                        UIHandler.trailer(provider_id, selected_source, referer)
                    else:
                        selected_source = result.sources[selected_index-1]
                        UIHandler.play(provider_id, selected_source, referer)
            else:
                if not result.sources or len(result.sources) == 0:
                    return
                if len(result.sources) == 1:
                    selected_source = result.sources[0]
                else:
                    source_labels =[f"Source {i + 1}" for i, _ in enumerate(result.sources)]                    
                    dialog = xbmcgui.Dialog()
                    selected_index = dialog.select("Select a source", source_labels)

                    if selected_index == -1:
                        selected_source = result.sources[0]
                    else:
                        selected_source = result.sources[selected_index]
                UIHandler.play(provider_id, selected_source, referer)

    @staticmethod
    def search(provider_id):
        """Create the search screen UI"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        keyboard = xbmc.Keyboard("", "Arama")
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            query = keyboard.getText()
        result_list = provider.search(query)
        if not result_list:
            return
        for item in result_list:
            
            url = item.url
            referer = f"https://{provider.OPTIONS.DOMAIN}/"
            if not url:
                return
            li = xbmcgui.ListItem(label=item.title)
            tmdb_json = tmdb_search(item.title)

            if tmdb_json and tmdb_json.get("results"):
                result = tmdb_json["results"][0]
                media_type = result.get("media_type")

                info = {"plot": result.get("overview"), "rating": result.get("vote_average")}
                art = {}

                genre_ids = result.get("genre_ids")
                if genre_ids and media_type:
                    info["genre"] = get_tmdb_genres(genre_ids, media_type)

                poster_path = result.get("poster_path")
                if poster_path:
                    art["poster"] = f"https://image.tmdb.org/t/p/w500{poster_path}"
                else:
                    art["poster"] = item.image

                backdrop_path = result.get("backdrop_path")
                if backdrop_path:
                    art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"

                if media_type == "movie":
                    info["title"] = result.get("title", item.title)
                    release_date = result.get("release_date")
                    if release_date:
                        info["premiered"] = release_date
                        if release_date.split("-"):
                            info["year"] = int(release_date.split("-")[0])
                    info["mediatype"] = "movie"
                elif media_type == "tv":
                    info["title"] = result.get("name", item.title)
                    first_air_date = result.get("first_air_date")
                    if first_air_date:
                        info["premiered"] = first_air_date
                        if first_air_date.split("-"):
                            info["year"] = int(first_air_date.split("-")[0])
                    info["mediatype"] = "tvshow"
                    info["tvshowtitle"] = info["title"]

                if "year" not in info and item.year:
                    try:
                        info["year"] = int(item.year)
                    except (ValueError, TypeError):
                        pass

                li.setArt(art)
                li.setInfo("video", info)
            else:
                li.setArt({"poster": item.image})
                info = {"title": item.title, "season": item.title, "mediatype": "season", "tvshowtitle": item.title}
                try:
                    if item.year:
                        info["year"] = int(item.year)
                except (ValueError, TypeError):
                    pass
                try:
                    if item.rating:
                        info["rating"] = float(item.rating)
                except (ValueError, TypeError):
                    pass
                li.setInfo("video", info)
            if item.type=="serie":
                isfolder=True
                li.setProperty('IsPlayable', 'false')
            else:
                li.setProperty('IsPlayable', 'true')
                isfolder=False
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(
                    router.load, provider_id, urllib.parse.quote(url, safe=""), urllib.parse.quote(referer, safe="")
                ),
                listitem=li,
                isFolder=isfolder,
            )
        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def play(provider_id: str, url: str, referer: str):
        """Play a video"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        result_media = provider.loadLinks(url, referer)
        if not isinstance(result_media, Media):
            return
        url = result_media.m3u8_url
        subtitles = result_media.subtitles
        play_item = xbmcgui.ListItem(path=url)
        play_item.setProperty("IsPlayable", "true")
        play_item.setContentLookup(False)
        play_item.setSubtitles(subtitles)

        # URL'nin MP4 olup olmadığını kontrol et
        if url.endswith(".mp4"):
            # Bu bir MP4 dosyası.
            # Kodi'nin varsayılan oynatıcısını kullanması için inputstream ayarı YAPMIYORUZ.
            # Sadece referer başlığını ayarlamak genellikle yeterlidir (eğer gerekiyorsa).
            if result_media.referer:
                referer = result_media.referer
                # Doğrudan oynatma için başlıklar bu şekilde eklenebilir.
                # URL'ye pipe | ekleyerek header bilgisi verilir.
                play_item.setPath(f"{url}|referer={referer}")

            xbmc.log(f"[ULTIMATE VIDEO ADDON] Playing direct MP4: {url}", xbmc.LOGINFO)

        else:
            # Bu bir HLS (m3u8) veya DASH akışıdır.
            # inputstream.adaptive ayarlarını burada yapıyoruz.
            play_item.setMimeType("application/vnd.apple.mpegurl")
            play_item.setProperty("inputstream", "inputstream.adaptive")
            play_item.setProperty("inputstream.adaptive.manifest_type", "hls")

            if result_media.referer:
                referer = result_media.referer
                play_item.setProperty("inputstream.adaptive.stream_headers", f"|referer={referer}")
                play_item.setProperty("inputstream.adaptive.manifest_headers", f"|referer={referer}")

        # Son olarak, hazırlanan listitem'ı oynatmak için Kodi'ye gönder
        xbmcplugin.setResolvedUrl(UIHandler.plugin.handle, True, listitem=play_item)

    @staticmethod
    def trailer(provider_id: str, url: str, referer: str):
        """Play a trailer"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        result_media = provider.trailer(url, referer)
        if not isinstance(result_media, Media):
            return
        m3u8url = result_media.m3u8_url
        subtitles = result_media.subtitles
        play_item = xbmcgui.ListItem(path=m3u8url)
        play_item.setProperty("IsPlayable", "true")
        play_item.setContentLookup(False)
        play_item.setSubtitles(subtitles)

        if 'youtube.com' in url:
            play_item.setPath(f"{m3u8url}")
            xbmc.log(f"[ULTIMATE VIDEO ADDON] Playing direct YouTube: {m3u8url}", xbmc.LOGINFO)
        # URL'nin MP4 olup olmadığını kontrol et
        elif m3u8url.endswith(".mp4"):
            # Bu bir MP4 dosyası.
            # Kodi'nin varsayılan oynatıcısını kullanması için inputstream ayarı YAPMIYORUZ.
            # Sadece referer başlığını ayarlamak genellikle yeterlidir (eğer gerekiyorsa).
            if result_media.referer:
                referer = result_media.referer
                # Doğrudan oynatma için başlıklar bu şekilde eklenebilir.
                # URL'ye pipe | ekleyerek header bilgisi verilir.
                play_item.setPath(f"{m3u8url}|referer={referer}")

            xbmc.log(f"[ULTIMATE VIDEO ADDON] Playing direct MP4: {m3u8url}", xbmc.LOGINFO)

        else:
            # Bu bir HLS (m3u8) veya DASH akışıdır.
            # inputstream.adaptive ayarlarını burada yapıyoruz.
            play_item.setMimeType("application/vnd.apple.mpegurl")
            play_item.setProperty("inputstream", "inputstream.adaptive")
            play_item.setProperty("inputstream.adaptive.manifest_type", "hls")

            if result_media.referer:
                referer = result_media.referer
                play_item.setProperty("inputstream.adaptive.stream_headers", f"|referer={referer}")
                play_item.setProperty("inputstream.adaptive.manifest_headers", f"|referer={referer}")

        # Son olarak, hazırlanan listitem'ı oynatmak için Kodi'ye gönder
        xbmcplugin.setResolvedUrl(UIHandler.plugin.handle, True, listitem=play_item)
