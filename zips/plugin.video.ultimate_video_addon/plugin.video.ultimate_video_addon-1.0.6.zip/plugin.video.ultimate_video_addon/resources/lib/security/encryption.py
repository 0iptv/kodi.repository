import re
import ast


def base10_2_n_string(d, n):
    s, t = "", d
    if t == 0:
        return "0"
    while t > 0:
        v = t % n
        s += (chr(v + 87), str(v))[v <= 9]
        t = int(t / n)
    return s[::-1]


def eval_unpack(p, a, c, k, e, d):
    a = c if not isinstance(a, int) else a

    def e_func(c):
        c = int(c)
        if c < a:
            pad = ""
        else:
            pad = e_func(c // a)  # Integer division kullanıyoruz
        c = c % a
        if c > 35:
            return pad + chr(c + 29)
        else:
            return pad + base10_2_n_string(c, 36)

    while c:
        c -= 1
        d[e_func(c)] = k[c] if k[c] else e_func(c)

    return re.sub(r"\w+", lambda match: d.get(match.group()) or match.group(), p)


def get_unpack_args_from_eval_str(data):
    """eval string'den parametreleri çıkarır - tempfile/importlib olmadan"""
    try:
        # Güvenli bir şekilde Python literal'ını parse et
        return ast.literal_eval(data)
    except:
        # Eğer ast.literal_eval başarısız olursa, basit regex ile parse et
        # Bu daha riskli ama bazen gerekli olabilir
        return eval(data)


def unpack(eval_text):
    """JavaScript eval kodunu unpack eder"""
    # eval(...) içindeki parametreleri bul
    match = re.search(r"return.*?}\s*(\(.*\))\s*\)", eval_text)
    if not match:
        return "No packed code found"

    # Parametreleri parse et
    params_str = match.group(1)
    params = get_unpack_args_from_eval_str(params_str)

    # Unpack işlemini gerçekleştir
    return eval_unpack(*params)
