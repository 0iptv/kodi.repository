from dataclasses import dataclass, field
from typing import List, Optional
from urllib.parse import urlparse


def is_valid_subtitle_url(url: str) -> bool:
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
    
@dataclass
class Media:
    """Represents a media."""
    _m3u8_url: str = field(default="")
    _subtitles: Optional[List[str]] = field(default=None)
    _referer: Optional[str] = field(default=None)
    
    @property
    def m3u8_url(self) -> str:
        return self._m3u8_url

    @m3u8_url.setter
    def m3u8_url(self, value: str):
        # URL doğrulaması
        if not isinstance(value, str):
            raise TypeError("M3U8 URL bir string olmalıdır")
        
        try:
            result = urlparse(value)
            if not all([result.scheme, result.netloc]):
                raise ValueError("Geçerli bir URL giriniz")
            
            self._m3u8_url = value.strip()
        except Exception as e:
            raise ValueError(f"Geçersiz M3U8 URL: {e}")

    @property
    def subtitles(self) -> List[str]:
        return self._subtitles or []

    @subtitles.setter
    def subtitles(self, value: List[str]):
        if not isinstance(value, list):
            raise TypeError("Altyazılar bir liste olmalıdır")
        
        cleaned_subtitles = list(dict.fromkeys(
            [url.strip() for url in value 
             if url.strip() and is_valid_subtitle_url(url.strip())]
        ))
        
        self._subtitles = cleaned_subtitles if cleaned_subtitles else None

    @property
    def referer(self) -> Optional[str]:
        return self._referer

    @referer.setter
    def referer(self, value: Optional[str]):
        if value is None:
            self._referer = None
            return

        if not isinstance(value, str):
            raise TypeError("Referer bir string olmalıdır")
        
        try:
            result = urlparse(value)
            if not all([result.scheme, result.netloc]):
                raise ValueError("Geçerli bir Referer URL'si giriniz")
            
            self._referer = value.strip()
        except Exception as e:
            raise ValueError(f"Geçersiz Referer URL: {e}")
