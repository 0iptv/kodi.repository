# -*- coding: utf-8 -*-
# main.py

import os
import sys

# Add the addon resources path
current_dir = os.path.dirname(__file__)
sys.path.append(os.path.join(current_dir, 'resources', 'lib'))

from ui import router

if __name__ == '__main__':
    router.run()