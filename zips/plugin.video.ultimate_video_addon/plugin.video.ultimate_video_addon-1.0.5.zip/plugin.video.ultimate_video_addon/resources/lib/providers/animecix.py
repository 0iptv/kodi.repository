
from typing import Any, Dict, List, Optional, Union
import re
import json
from bs4 import BeautifulSoup
from utils.parser import Parser
from model.chapter import Chapter
from utils.js2py import evalJS
from urllib.parse import urlparse

from integrations import api_connector
from security.encryption import unpack

from model.provider_options import ProviderOptions
from model.category import CategoryItem
from model.component import OtherComponent, SoupComponent
from core.provider import Provider
from model.media import Media
from model.video_content import ContentType
from model.movie import Movie
from model.serie import ChapterEl, Serie
from model.video_content import ListContent
from services import content_service


def categoryParser(response: Dict[str, Any], options: Dict[str, str]) -> List[ListContent]:
    results = response.get("pagination", {}).get("data", []) or response.get("data",[])
    items = []
    for result in results:
        item = ListContent()
        item.title = result.get(options.get("title"))
        item.image = result.get(options.get("image"))
        item.type = "serie" if result.get(options.get("type")) =="anime" else "movie"
        item.url = f"https://{Animecix_Options.DOMAIN}/secure/titles/{result.get(options.get('url'))}?titleId={result.get(options.get('url'))}"
        items.append(item)
    return items

Animecix_Options = ProviderOptions(
    DOMAIN="animecix.tv",
    HEADERS={
        "x-e-h": "7Y2ozlO+QysR5w9Q6Tupmtvl9jJp7ThFH8SB+Lo7NvZjgjqRSqOgcT2v4ISM9sP10LmnlYI8WQ==.xrlyOBFS5BHjQ2Lk"
    },
    COMPONENTS={
        "MEDIA_GRID": OtherComponent(
            callback=categoryParser,
            options={
                "title": "name",
                "image": "poster",
                "url": "id",
                "type":"title_type",
            },
        ),
        "MINI_MEDIA_GRID": OtherComponent(
            callback=categoryParser,
            options={
                "title": "title_name",
                "image": "title_poster",
                "url": "title_id",
                "type":"title_type",
            },
        ),
    },
    LOAD_LINK={},
)

class Animecix(Provider):
    """docstring for Animecix."""

    OPTIONS = Animecix_Options
    NAME = "ANIMECIX"
    ICON = ""  # Add icon file name if available

    CATEGORIES = {
        "last-episodes": CategoryItem(
            name="Son Eklenen Bölümler",
            url=f"https://{Animecix_Options.DOMAIN}/secure/last-episodes",
            is_paging=False,
            headers=Animecix_Options.HEADERS,
            component=Animecix_Options.COMPONENTS["MINI_MEDIA_GRID"],
        ),
        "series": CategoryItem(
            name="Seriler",
            url=f"https://{Animecix_Options.DOMAIN}/secure/titles?type=series&onlyStreamable=true",
            is_paging=True,
            headers=Animecix_Options.HEADERS,
            component=Animecix_Options.COMPONENTS["MEDIA_GRID"],
        ),
        "movies": CategoryItem(
            name="Filmler",
            url=f"https://{Animecix_Options.DOMAIN}/secure/titles?type=movie&onlyStreamable=true",
            is_paging=True,
            headers=Animecix_Options.HEADERS,
            component=Animecix_Options.COMPONENTS["MEDIA_GRID"],
        ),
    }

    @classmethod
    def Category(cls, category_id: str, page_number=1) -> Optional[List[ListContent]]:
        category = cls.CATEGORIES.get(category_id, None)
        if not category:
            return None
        
        return content_service.get_category(category, page_number)

    @classmethod
    def load(cls, url: str, referer: str) -> Union[Movie, Serie, Chapter, None]:
        response = api_connector.make_request(url, headers=Animecix_Options.HEADERS)
        if not response:
            return None
        if isinstance(response,str) and response.startswith("Found. Redirecting to "):
            match = re.search(r'https?://[^\s\'"()]+', response)
            if match:
                chapter=Chapter()
                url=match.group(0)
                chapter.sources=[url]
                return chapter
        if isinstance(response, str):
            return None

        title_data = response.get("title", {})
        title_id = url.split("titleId=")[-1]

        if title_data.get("title_type") == "anime":
            serie = Serie()
            serie.title = title_data.get("name")
            serie.image = title_data.get("poster")
            serie.year = str(title_data.get("year"))
            serie.plot = title_data.get("description")
            serie.genres = [tag.get("name") for tag in title_data.get("genres", [])]
            serie.rating = str(title_data.get("tmdb_vote_average"))
            serie.chapters = []

            for season in title_data.get("seasons", []):
                season_response = api_connector.make_request(f"https://{Animecix_Options.DOMAIN}/secure/related-videos?episode=1&season={season.get('number')}&videoId=0&titleId={title_id}", headers=Animecix_Options.HEADERS)
                if season_response:
                    videos = season_response.get("videos", [])
                    print(videos)
                    for video in videos:
                        print(video)
                        title = f"{video.get('season_num')}. Sezon {video.get('episode_num')}. Bölüm"
                        url = f"https://{Animecix_Options.DOMAIN}/{video.get('url')}"
                        chapter = ChapterEl(title, url)
                        serie.chapters.append(chapter)
            return serie
        else:
            movie = Movie()
            movie.title = title_data.get("name")
            movie.image = title_data.get("poster")
            movie.year = str(title_data.get("year"))
            movie.plot = title_data.get("description")
            movie.genres = [tag.get("name") for tag in title_data.get("tags", [])]
            movie.rating = str(title_data.get("tmdb_vote_average"))
            movie.sources = [video.get("url") for video in title_data.get("videos", [])]
            return movie

    @classmethod
    def search(cls, query: str) -> Optional[List[ListContent]]:
        url = f"https://{Animecix_Options.DOMAIN}/secure/search/{query}?limit=20"
        response = api_connector.make_request(url, Animecix_Options.HEADERS)
        if not response:
            return None
        
        results = response.get("results", [])
        items = []
        for result in results:
            item = ListContent()
            item.title = result.get("name")
            item.image = result.get("poster")            
            item.type = "serie" if result.get("title_type") =="anime" else "movie"
            item.url = f"https://{Animecix_Options.DOMAIN}/secure/titles/{result.get('id')}?titleId={result.get('id')}"
            items.append(item)
        return items

    @classmethod
    def loadLinks(cls, url: str, referer: str) -> Optional[Media]:
        iframe_url = url
        api_connector.make_request(url, headers={"Referer":f"https://{Animecix_Options.DOMAIN}/"})

        video_key = iframe_url.split("/")[-1].split("?")[0]
        video_url = ""
        if "tau-video.xyz" in iframe_url:
            video_url = f"https://tau-video.xyz/api/video/{video_key}"
        elif "fang-heshan.store" in iframe_url:
            video_url = f"https://fang-heshan.store/file/tau-video/{video_key}/"
        
        if not video_url:
            return None
        m3u8_parsed = urlparse(video_url)
        iframe_parsed = urlparse(iframe_url)      
        if m3u8_parsed.netloc != iframe_parsed.netloc:
            iframe_url=f"{iframe_parsed.scheme}://{iframe_parsed.netloc}/"
        response = api_connector.make_request(video_url, headers={"Referer": iframe_url})
        if not response:
            return None

        media = Media()
        urls = response.get("urls", [])
        if urls:
            try:
                import xbmcgui # type: ignore
                quality_labels = [source['label'] for source in urls]
                dialog = xbmcgui.Dialog()
                selected_index = dialog.select(
                    'Video Kalitesi Seç', 
                    quality_labels
                )
                if selected_index != -1:
                    media.m3u8_url = urls[selected_index].get("url")
                else:
                    media.m3u8_url = urls[0].get("url")
            except:
                media.m3u8_url = urls[0].get("url")                
            
            media.referer = f"https://{Animecix_Options.DOMAIN}/"
        return media
