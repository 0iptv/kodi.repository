from dataclasses import dataclass, field
from typing import List, Optional
from model.video_content import BaseContent


@dataclass
class Movie(BaseContent):
    """Represents a movie."""

    _sources: Optional[List[str]] = field(default=None)
    _genres: Optional[List[str]] = None
    _plot: Optional[str] = None
    _trailer: Optional[str] = None
    
    @property
    def sources(self) -> List[str]:
        return self._sources or [] 

    @sources.setter
    def sources(self, value: List[str]):
        # Doğrulama kontrolleri
        if not isinstance(value, list):
            raise TypeError("Sources bir liste olmalıdır")
        
        if not all(isinstance(item, str) for item in value):
            raise ValueError("Tüm source elemanları string olmalıdır")        
        
        cleaned_sources = list(dict.fromkeys(
            [source.strip() for source in value if source.strip()]
        ))
        
        self._sources = cleaned_sources

    @property
    def genres(self) -> List[str]:
        return self._genres or []

    @genres.setter
    def genres(self, value: Optional[List[str]]):
        if value is None:
            self._genres = None
            return

        if not isinstance(value, list):
            raise TypeError("Türler bir liste olmalıdır")
        
        # Boş ve tekrar eden türleri temizle
        cleaned_genres = list(dict.fromkeys(
            [genre.strip() for genre in value if genre.strip()]
        ))
        
        self._genres = cleaned_genres if cleaned_genres else None

    @property
    def plot(self) -> Optional[str]:
        return self._plot

    @plot.setter
    def plot(self, value: Optional[str]):
        if value is None:
            self._plot = None
            return

        if not isinstance(value, str):
            raise TypeError("Plot bir string olmalıdır")
        
        # Boşlukları temizle ve çok uzun plotları kes
        cleaned_plot = value.strip()
        
        # Opsiyonel: Plot için maksimum uzunluk sınırı
        MAX_PLOT_LENGTH = 1000
        if len(cleaned_plot) > MAX_PLOT_LENGTH:
            cleaned_plot = cleaned_plot[:MAX_PLOT_LENGTH] + "..."
        
        self._plot = cleaned_plot if cleaned_plot else None
    @property
    def trailer(self):
        return self._trailer

    @trailer.setter
    def trailer(self, value):
        self._trailer = value