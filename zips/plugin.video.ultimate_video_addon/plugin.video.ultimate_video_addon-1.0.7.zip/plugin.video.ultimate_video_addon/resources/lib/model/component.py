from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union

from model.chapter import Chapter

from model.movie import Movie
from model.serie import Serie
from model.video_content import ListContent


@dataclass
class SoupComponent(object):
    """Docstring for Component."""

    item_selector: str
    child_selector: Dict[str, str]


@dataclass
class OtherComponent:
    callback: Callable[[Any, Any], Union[Movie, Serie, Chapter, List[ListContent], None]]
    options: Any
