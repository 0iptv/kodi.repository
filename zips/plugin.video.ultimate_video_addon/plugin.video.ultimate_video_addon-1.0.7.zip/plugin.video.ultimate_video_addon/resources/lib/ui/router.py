import urllib.parse
from routing import Plugin  # type: ignore
from ui.ui_handler import UIHandler

# Create a plugin instance
plugin = Plugin()
UIHandler.plugin = plugin


@plugin.route("/")
def home():
    """Create the home screen UI"""
    UIHandler.create_providers()


@plugin.route("/provider/<provider_id>")
def provider(provider_id: str):
    """Create the home screen UI"""
    UIHandler.create_provider_home(provider_id)


@plugin.route("/category/<provider_id>/<category_id>/<page_number>")
def category(provider_id: str, category_id: str, page_number=1):
    """Create the list screen UI for a given list"""
    UIHandler.category(provider_id, category_id, page_number)


@plugin.route("/load/<provider_id>/<url>/<referer>")
def load(provider_id: str, url: str, referer: str):
    """Create the list screen UI for a given list"""
    decoded_url = urllib.parse.unquote(url)
    decoded_referer = urllib.parse.unquote(referer)
    UIHandler.load(provider_id, decoded_url, decoded_referer)


@plugin.route("/play/<provider_id>/<url>/<referer>")
def play(provider_id: str, url: str, referer: str, ):
    """Play a video"""
    # Placeholder for playing the video
    decoded_url = urllib.parse.unquote(url)
    decoded_referer = urllib.parse.unquote(referer)
    UIHandler.play(provider_id, decoded_url, decoded_referer)

@plugin.route("/trailer/<provider_id>/<url>/<referer>")
def trailer(provider_id: str, url: str, referer: str, ):
    """Play a video"""
    # Placeholder for playing the video
    decoded_url = urllib.parse.unquote(url)
    decoded_referer = urllib.parse.unquote(referer)
    UIHandler.trailer(provider_id, decoded_url, decoded_referer)

@plugin.route("/search/<provider_id>")
def search(provider_id: str):
    """Create the search screen UI"""
    UIHandler.search(provider_id)


def run():
    """Run the plugin"""
    plugin.run()
