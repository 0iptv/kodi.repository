import json
import random
import string

from integrations.api_connector import make_request_with_get, make_request_with_payload
from utils import logger

YOUTUBE_CONFIG = {
    'android': {
        'user_agent': (
            "com.google.android.youtube/19.30.36 "
            "(Linux; U; Android 14; en_US) gzip"
        ),
        'client_name': "ANDROID",
        'client_version': "19.30.36",
        'os_name': "Android",
        'os_version': "14",
        'sdk_version': "34",
        'hl': "en",
        'gl': "US",
        'utc_offset': -240
    },
    'web': {
        'user_agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/87.0.4280.101 Safari/537.36'
        ),
        'hl': "en",
        'has_verified': 1,
        'socs_cookie': 'SOCS=CAI'
    },
    'api': {
        'player_endpoint': "https://youtubei.googleapis.com/youtubei/v1/player"
    },
    'nonce': {
        'client_playback': 16,
        't_param': 12
    }
}

class YouTubeHelper:
    @staticmethod
    def generate_nonce(length):
        """Generate a random nonce string."""
        chars = string.ascii_letters + string.digits
        return ''.join(random.choice(chars) for _ in range(length))

    @staticmethod
    def fetch_cookies(video_url):
        """Fetch YouTube cookies for a video."""
        watch_url = (
            f"{video_url}"
            f"&hl={YOUTUBE_CONFIG['web']['hl']}"
            f"&has_verified={YOUTUBE_CONFIG['web']['has_verified']}"
        )
        
        headers = {
            'Cookie': YOUTUBE_CONFIG['web']['socs_cookie'],
            'User-Agent': YOUTUBE_CONFIG['web']['user_agent']
        }
        
        try:
            response = make_request_with_get(watch_url, headers=headers)
            if response is None:
                return None
            cookies = response.headers.get('Set-Cookie', [])
            cookie_values = [cookie.split(';')[0] for cookie in cookies]
            cookies_string = '; '.join(cookie_values)
            return cookies_string
        except Exception as e:
            logger.log(f"Error fetching cookies: {str(e)}", logger.LOGERROR)
            return ''

    @staticmethod
    def fetch_video_data(video_url):
        """Fetch video data from YouTube API."""
        try:
            cookies = YouTubeHelper.fetch_cookies(video_url)
            videoId=video_url.split("?v=")[1]
            payload = {
                'videoId': videoId,
                'cpn': YouTubeHelper.generate_nonce(YOUTUBE_CONFIG['nonce']['client_playback']),
                'contentCheckOk': True,
                'racyCheckOk': True,
                'playbackContext': {'contentPlaybackContext': {'html5Preference': 'HTML5_PREF_WANTS'}},
                'context': {
                    'client': {
                        'clientName': YOUTUBE_CONFIG['android']['client_name'],
                        'clientVersion': YOUTUBE_CONFIG['android']['client_version'],
                        'platform': "MOBILE",
                        'osName': YOUTUBE_CONFIG['android']['os_name'],
                        'osVersion': YOUTUBE_CONFIG['android']['os_version'],
                        'androidSdkVersion': YOUTUBE_CONFIG['android']['sdk_version'],
                        'hl': YOUTUBE_CONFIG['android']['hl'],
                        'gl': YOUTUBE_CONFIG['android']['gl'],
                        'utcOffsetMinutes': YOUTUBE_CONFIG['android']['utc_offset']
                    },
                    'request': {
                        'internalExperimentFlags': [],
                        'useSsl': True
                    },
                    'user': {
                        'lockedSafetyMode': False
                    }
                }
            }

            url = (
            f"{YOUTUBE_CONFIG['api']['player_endpoint']}?prettyPrint=False"
            f"&t={YouTubeHelper.generate_nonce(YOUTUBE_CONFIG['nonce']['t_param'])}"
            f"&id={videoId}"
            )

            headers = {
                'Content-Type': 'application/json',
                'User-Agent': YOUTUBE_CONFIG['android']['user_agent'],
                'x-goog-api-format-version': '2',
                'Cookie': cookies
            }
            
            response = make_request_with_payload(
                url,
                headers=headers,
                payload=payload
            )
            if response is None:
                return None
            
            data = response.json()
            if 'streamingData' in data and 'formats' in data['streamingData']:
                return data['streamingData']['formats'][0]['url']
            
            return None
            
        except Exception as e:
            logger.log(
                f"Error fetching video data: {str(e)}", 
                logger.LOGERROR
            )
            return None 
