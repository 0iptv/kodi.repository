# utils/logger.py
try:
    import xbmc # type: ignore
    XBMC_AVAILABLE = True
except ImportError:
    XBMC_AVAILABLE = False

# Log Seviye Sabitleri
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGDEBUG = 4

class Logger:
    def log(self, message, level=LOGINFO):
        """
        Log mesajı yaz
        
        :param message: Log mesajı
        :param level: Log seviyesi (LOGINFO, LOGWARNING, LOGERROR, LOGDEBUG)
        """
        # Log seviyesi metni
        level_text = {
            LOGINFO: "INFO",
            LOGWARNING: "WARNING", 
            LOGERROR: "ERROR",
            LOGDEBUG: "DEBUG"
        }.get(level, "UNKNOWN")
        
        # Log formatı
        log_message = f"[{level_text}] {message}"
        
        # XBMC/Kodi log varsa öncelikle onu kullan
        if XBMC_AVAILABLE:
            xbmc_level = {
                LOGINFO: xbmc.LOGINFO,
                LOGWARNING: xbmc.LOGWARNING,
                LOGERROR: xbmc.LOGERROR,
                LOGDEBUG: xbmc.LOGDEBUG
            }.get(level, xbmc.LOGINFO)
            xbmc.log(log_message, xbmc_level)
        else:
            # Konsola yazdır
            print(log_message)

# Global logger instance
logger = Logger()

# Hızlı erişim için global değişkenler
LOGINFO = LOGINFO
LOGWARNING = LOGWARNING
LOGERROR = LOGERROR
LOGDEBUG = LOGDEBUG

# Doğrudan kullanım için log fonksiyonu
def log(message, level=LOGINFO):
    logger.log(message, level)
