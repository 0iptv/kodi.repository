from providers.hdfilmcehennemi import HdFilmCehenenmi
from providers.animecix import Animecix

tmdb_default_api, fanarttv_default_api = 'b370b60447737762ca38457bd77579b3', 'fa836e1c874ba95ab08a14ee88e05565'
PROVIDERS = {
    'hdfilm': HdFilmCehenenmi,
    'animecix': Animecix
}


