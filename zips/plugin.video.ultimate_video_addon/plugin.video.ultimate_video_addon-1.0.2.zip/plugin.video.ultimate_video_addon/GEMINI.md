
# Project Overview

This project is a Kodi video addon named "Ultimate Video Addon". It is written in Python and its main purpose is to provide video content to Kodi users by scraping various websites. The addon is structured with a clear separation of concerns, dividing the logic into UI, services, providers, and model layers.

## Main Technologies

*   **Python 3:** The core language of the addon.
*   **Kodi Addon Framework:** The addon is built upon the Kodi addon framework, using libraries like `xbmc`, `xbmcgui`, and `xbmcplugin`.
*   **BeautifulSoup4:** Used for parsing HTML content scraped from websites.
*   **js2py:** Used to execute JavaScript code found on the scraped websites, which is often used to obfuscate video links.
*   **Routing:** The `routing` library is used to handle URL routing within the addon.

## Architecture

The addon follows a modular architecture:

*   **`main.py`:** The main entry point of the addon. It initializes the router and starts the plugin.
*   **`resources/lib/ui`:** This layer is responsible for the user interface.
    *   **`router.py`:** Defines the URL routes for different sections of the addon (e.g., home, categories, search, play).
    *   **`ui_handler.py`:** Handles the creation of UI elements like lists, menus, and playable items using the data provided by the service layer.
*   **`resources/lib/services`:** This layer acts as a bridge between the UI and the providers.
    *   **`content_service.py`:** Provides a generic way to fetch and parse content from providers.
*   **`resources/lib/providers`:** This layer contains the logic for scraping content from specific websites.
    *   **`hdfilmcehennemi.py`:** A provider that scrapes content from the website `hdfilmcehennemi.la`.
*   **`resources/lib/model`:** This layer defines the data models for the content (e.g., `Movie`, `Serie`, `Chapter`, `Media`).
*   **`resources/lib/integrations`:** This layer handles the communication with external services.
    *   **`api_connector.py`:** A utility for making HTTP requests.
*   **`resources/lib/security`:** This layer contains security-related functionality.
    *   **`encryption.py`:** Contains functions for de-obfuscating data, like the `unpack` function used for JavaScript de-obfuscation.
*   **`resources/lib/utils`:** This layer contains utility functions.
    *   **`parser.py`:** A utility for parsing HTML content using BeautifulSoup.
    *   **`js2py.py`:** A utility for executing JavaScript code.

# Building and Running

This is a Kodi addon and is not meant to be run as a standalone application. To run this addon, you need to have Kodi installed.

1.  **Installation:**
    *   Copy the entire project folder to the Kodi addons directory.
    *   Alternatively, you can zip the project folder and install it from the "Install from zip file" option in Kodi's addon browser.

2.  **Running:**
    *   Once installed, the addon will be available in the "Video add-ons" section of Kodi.
    *   Navigate to the addon and open it to see the main menu.

# Development Conventions

*   **Modularity:** The code is well-structured into modules with specific responsibilities.
*   **Typing:** The code uses type hints, which improves readability and helps with static analysis.
*   **Separation of Concerns:** The UI, business logic, and data scraping are separated into different layers.
*   **Provider-based Architecture:** The addon is designed to be extensible with new providers. Each provider is a class that implements a common interface for fetching and parsing content.
*   **Configuration:** The provider-specific configurations, such as domain, headers, and component selectors, are defined in a `ProviderOptions` object.
