from typing import List, Optional, Union
from bs4 import BeautifulSoup
from model.chapter import Chapter
from model.component import SoupComponent, OtherComponent
from model.video_content import ListContent
from model.movie import Movie
from model.serie import ChapterEl, Serie


class Parser:
    @staticmethod
    def parse_beautiful_soup(html_content: str):
        return BeautifulSoup(html_content, "html.parser")

    @staticmethod
    def parse_category(
        html_content: str, component: Union[SoupComponent, OtherComponent]
    ) -> Optional[List[ListContent]]:
        if isinstance(component, SoupComponent):
            soup = Parser.parse_beautiful_soup(html_content)
            items = []
            for item_element in soup.select(component.item_selector):
                child_selectors = component.child_selector
                list_content = ListContent()
                for [key, child_selector] in child_selectors.items():
                    if child_selector == "":
                        child = item_element
                    else:
                        child = item_element.select_one(child_selector)
                    if child:
                        if key == "image":
                            list_content.image = child.get("data-src") or child.get("src")
                        elif key == "url":
                            list_content.url = child.get("href")
                        else:
                            setattr(list_content,key,child.text.strip())
                items.append(list_content)
            return items
        elif isinstance(component, OtherComponent):
            result = component.callback(html_content, None)
            if isinstance(result, list):
                return result
        return None

    @staticmethod
    def parse_movie(
        html_content: str, component: Union[SoupComponent, OtherComponent]
    ) -> Optional[Movie]:
        if isinstance(component, SoupComponent):
            soup = Parser.parse_beautiful_soup(html_content)
            if component.item_selector == "":
                item_element = soup
            else:
                item_element = soup.select(component.item_selector)
            if item_element:
                child_selectors = component.child_selector
                movie = Movie()
                for [key, child_selector] in child_selectors.items():
                    if key == "sources":
                        child = item_element.select(child_selector)
                        attribute = component.child_selector.get(
                            "source_attribute", "href"
                        )
                        hrefs = [
                            link.get(attribute) for link in child if link.get(attribute)
                        ]
                        movie.sources = hrefs
                    elif key == "genres":
                        child = item_element.select(child_selector)
                        genres = [
                            genre.text.strip() for genre in child if genre.text.strip()
                        ]
                        movie.genres = genres
                    elif key == "source_attribute":
                        continue
                    else:
                        child = item_element.select_one(child_selector)
                        if child:
                            if key == "image":
                                movie.image = child.get("data-src")
                            else:
                                setattr(movie,key,child.text.strip())
                return movie
        elif isinstance(component, OtherComponent):
            result = component.callback(html_content, None)
            if isinstance(result, Movie):
                return result

        return None

    @staticmethod
    def parse_chapter(
        html_content: str, component: Union[SoupComponent, OtherComponent]
    ) -> Optional[Chapter]:
        if isinstance(component, SoupComponent):
            soup = Parser.parse_beautiful_soup(html_content)
            if component.item_selector == "":
                item_element = soup
            else:
                item_element = soup.select(component.item_selector)
            attribute = component.child_selector.get("source_attribute", "href")
            chapter = Chapter()
            if isinstance(item_element, list):
                sources = [
                    source.get(attribute)
                    for source in item_element
                    if source.get(attribute)
                ]
                chapter.sources = sources
                return chapter
        elif isinstance(component, OtherComponent):
            result = component.callback(html_content, None)
            if isinstance(result, Chapter):
                return result
        return None

    @staticmethod
    def parse_serie(
        html_content: str, component: Union[SoupComponent, OtherComponent]
    ) -> Optional[Serie]:
        if isinstance(component, SoupComponent):
            soup = Parser.parse_beautiful_soup(html_content)
            if component.item_selector == "":
                item_element = soup
            else:
                item_element = soup.select(component.item_selector)
            if item_element:
                child_selectors = component.child_selector
                serie = Serie()
                for (
                    key,
                    child_selector,
                ) in child_selectors.items():  # Corrected loop syntax
                    if key == "chapter_url":
                        child = item_element.select(child_selector)
                        chapters = [
                            ChapterEl(
                                title=chapter.select_one(
                                    child_selectors["chapter_title"]
                                ).text.strip(),
                                url=chapter.get("href"),
                            )
                            for chapter in child
                            if chapter
                        ]
                        serie.chapters = chapters
                    elif key == "chapter_title":
                        continue
                    elif key == "genres":
                        child = item_element.select(child_selector)
                        genres = [
                            genre.text.strip() for genre in child if genre.text.strip()
                        ]
                        serie.genres = genres
                    else:
                        child = item_element.select_one(child_selector)
                        if child:
                            if key == "image":
                                serie.image = child.get("data-src")
                            else:
                                setattr(serie,key,child.text.strip())
                return serie
        elif isinstance(component, OtherComponent):
            result = component.callback(html_content, component.options)
            if isinstance(result, Serie):
                return result

        return None
