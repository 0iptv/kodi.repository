from dataclasses import dataclass, field
from typing import List, Optional
from model.video_content import BaseContent


@dataclass
class ChapterEl:
    """Represents an episode of a series."""

    title: str = field(default="")
    url: str = field(default="")


@dataclass
class Serie(BaseContent):
    """Represents a series."""

    _chapters: Optional[List[ChapterEl]] = field(default=None)
    _genres: Optional[List[str]] = None
    _plot: Optional[str] = None
    _trailer: Optional[str] = None

    @property
    def chapters(self) -> List[ChapterEl]:
        return self._chapters or []

    @chapters.setter
    def chapters(self, value: Optional[List[ChapterEl]]):
        if value is None:
            self._chapters = None
            return

        if not isinstance(value, list):
            raise TypeError("Bölümler bir liste olmalıdır")
        
        # Bölüm doğrulaması
        cleaned_chapters = []
        for chapter in value:
            if not isinstance(chapter, ChapterEl):
                raise TypeError("Her bölüm bir ChapterEl örneği olmalıdır")
            
            cleaned_chapters.append(chapter)
        
        self._chapters = cleaned_chapters if cleaned_chapters else None

    @property
    def genres(self) -> List[str]:
        return self._genres or []

    @genres.setter
    def genres(self, value: Optional[List[str]]):
        if value is None:
            self._genres = None
            return

        if not isinstance(value, list):
            raise TypeError("Türler bir liste olmalıdır")

        # Boş ve tekrar eden türleri temizle
        cleaned_genres = list(dict.fromkeys([str(genre).strip() for genre in value if str(genre).strip()]))

        self._genres = cleaned_genres if cleaned_genres else None

    @property
    def plot(self) -> Optional[str]:
        return self._plot

    @plot.setter
    def plot(self, value: Optional[str]):
        if value is None:
            self._plot = None
            return

        if not isinstance(value, str):
            raise TypeError("Plot bir string olmalıdır")

        # Boşlukları temizle ve çok uzun plotları kes
        cleaned_plot = value.strip()

        # Plot için maksimum uzunluk sınırı
        MAX_PLOT_LENGTH = 2000
        if len(cleaned_plot) > MAX_PLOT_LENGTH:
            cleaned_plot = cleaned_plot[:MAX_PLOT_LENGTH] + "..."

        self._plot = cleaned_plot if cleaned_plot else None
    @property
    def trailer(self):
        return self._trailer

    @trailer.setter
    def trailer(self, value):
        self._trailer = value
