from typing import Any
from js2py.evaljs import EvalJs
import base64


def atob(s):
    return base64.b64decode("{}".format(s)).decode("unicode-escape")


def evalJS(jsCode: str) -> Any:
    context = EvalJs({"atob": atob})
    return context.eval(jsCode)
