import os
import urllib.parse
import xbmc  # type: ignore
import xbmcgui  # type: ignore
import xbmcplugin  # type: ignore
import xbmcaddon # type: ignore
from routing import Plugin
from typing import Optional
from model.chapter import Chapter
from model.media import Media
from model.movie import Movie
from model.serie import Serie
from core import constants
from ui import router


class UIHandler:
    plugin: Optional[Plugin] = None

    @staticmethod
    def create_provider_home(provider_id: str):
        """Creates the directory items for the home page."""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        # Add a static link to search
        li = xbmcgui.ListItem(label="Search")
        xbmcplugin.addDirectoryItem(
            handle=UIHandler.plugin.handle,
            url=UIHandler.plugin.url_for(router.search, provider_id),
            listitem=li,
            isFolder=True,
        )
        for [category_id, category] in provider.CATEGORIES.items():
            li = xbmcgui.ListItem(label=category.name)
            path=xbmcaddon.Addon().getAddonInfo("path")
            li.setArt({"poster":os.path.join(path, 'resources', 'media', "category.png")})
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(router.category, provider_id, category_id, 1),
                listitem=li,
                isFolder=True,
            )
        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def create_providers():
        """Creates the directory items for the home page."""

        if not UIHandler.plugin:
            return

        for provider_id, provider in constants.PROVIDERS.items():
            li = xbmcgui.ListItem(label=provider.NAME)
            if provider.ICON:
                path=xbmcaddon.Addon().getAddonInfo("path")
                li.setArt({"poster":os.path.join(path, 'resources', 'media', f"{provider.ICON}")})
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(router.provider, provider_id),
                listitem=li,
                isFolder=True,
            )
        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def category(provider_id: str, category_id: str, page_number=1):
        """Create the list screen UI for a given category"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        category = provider.CATEGORIES.get(category_id, None)
        if not category:
            return
        result_list = provider.Category(category_id, page_number)
        if not result_list:
            return
        for item in result_list:
            li = xbmcgui.ListItem(label=item.title)
            li.setArt({"poster":item.image})
            li.setInfo('video', {
                'title': item.title,
                'season': item.title,
                'mediatype': 'season',
                'year': int(item.year),
                'rating': float(item.rating),
                'tvshowtitle': item.title
            })
            url = item.url
            referer = category.headers.get("referer", f"https://{provider.OPTIONS.DOMAIN}/")
            if not url:
                return
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(
                    router.load, provider_id, urllib.parse.quote(url, safe=""), urllib.parse.quote(referer, safe="")
                ),
                listitem=li,
                isFolder=True,
            )

        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def load(provider_id: str, content_url: str, referer: str):
        """Create the list screen UI for a given list"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        result = provider.load(content_url, referer)
        if not result:
            return
        if isinstance(result, Serie):
            for item in result.chapters:
                serie_url = item.url
                referer = content_url
                li = xbmcgui.ListItem(label=item.title)
                li.setArt({"poster":result.image})
                li.setInfo('video', {
                    'title': result.title,
                    'season': result.title,
                    'mediatype': 'season',
                    'genre': result.genres,
                    'year': int(result.year),
                    'plot': result.plot,
                    'rating': float(result.rating),
                    'tvshowtitle': result.title
                })
                xbmcplugin.addDirectoryItem(
                    handle=UIHandler.plugin.handle,
                    url=UIHandler.plugin.url_for(
                        router.load,
                        provider_id,
                        urllib.parse.quote(serie_url, safe=""),
                        urllib.parse.quote(referer, safe=""),
                    ),
                    listitem=li,
                    isFolder=True,
                )
        elif isinstance(result, Movie) or isinstance(result, Chapter):
            referer = content_url
            for index, source in enumerate(result.sources):
                li = xbmcgui.ListItem(label=f"Source {index + 1}")
                if isinstance(result, Movie):
                    li.setArt({"poster": result.image})
                    li.setInfo('video', {
                        'genre': result.genres,
                        'year': int(result.year),
                        'plot': result.plot,
                        'rating': float(result.rating),
                        'title': result.title,
                        'mediatype': 'movie'
                    })
                li.setProperty("IsPlayable", "true")
                li.setMimeType("application/vnd.apple.mpegurl")
                
                xbmcplugin.addDirectoryItem(
                    handle=UIHandler.plugin.handle,
                    url=UIHandler.plugin.url_for(
                        router.play,
                        provider_id,
                        urllib.parse.quote(source, safe=""),
                        urllib.parse.quote(referer, safe=""),
                    ),
                    listitem=li,
                    isFolder=False,
                )

        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def search(provider_id):
        """Create the search screen UI"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        keyboard = xbmc.Keyboard("", "Arama")
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            query = keyboard.getText()
        result_list = provider.search(query)
        if not result_list:
            return
        for item in result_list:
            li = xbmcgui.ListItem(label=item.title)
            li.setInfo("video", {"title": item.title, "year": item.year, "rating": item.rating})
            li.setProperty("fanart_image", item.image)
            url = item.url
            referer = f"https://{provider.OPTIONS.DOMAIN}/"
            if not url:
                return
            xbmcplugin.addDirectoryItem(
                handle=UIHandler.plugin.handle,
                url=UIHandler.plugin.url_for(
                    router.load, provider_id, urllib.parse.quote(url, safe=""), urllib.parse.quote(referer, safe="")
                ),
                listitem=li,
                isFolder=True,
            )
        xbmcplugin.endOfDirectory(UIHandler.plugin.handle)

    @staticmethod
    def play(provider_id: str, url: str, referer: str):
        """Play a video"""
        if not UIHandler.plugin:
            return
        provider = constants.PROVIDERS.get(provider_id, None)
        if not provider:
            return
        result_media = provider.loadLinks(url, referer)
        if not isinstance(result_media, Media):
            return
        url = result_media.m3u8_url
        subtitles = result_media.subtitles
        play_item = xbmcgui.ListItem(path=url)
        play_item.setProperty("IsPlayable", "true")
        play_item.setMimeType("application/vnd.apple.mpegurl")
        if result_media.referer:
            referer = result_media.referer
            play_item.setProperty("inputstream.adaptive.manifest_headers", f"|referer={referer}")
            play_item.setProperty("inputstream.adaptive.stream_headers", f"|referer={referer}")
        play_item.setProperty("inputstream", "inputstream.adaptive")
        play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
        play_item.setContentLookup(False)
        play_item.setSubtitles(subtitles)
        xbmcplugin.setResolvedUrl(UIHandler.plugin.handle, True, listitem=play_item)
