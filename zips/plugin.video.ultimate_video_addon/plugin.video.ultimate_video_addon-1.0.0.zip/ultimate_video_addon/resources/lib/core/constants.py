from providers.hdfilmcehennemi import HdFilmCehenenmi

PROVIDERS = {
    'hdfilm': HdFilmCehenenmi
}


