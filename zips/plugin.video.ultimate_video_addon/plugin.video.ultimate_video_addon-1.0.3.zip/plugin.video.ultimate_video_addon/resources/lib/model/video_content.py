from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
from urllib.parse import urlparse


class ContentType(Enum):
    MOVIE = "movie"
    SERIE = "serie"
    VIDEO = "video"
    CHAPTER = "chapter"


@dataclass
class BaseContent:
    _title: str = field(default="")
    _year: str = field(default="0")
    _image: str = field(default="")
    _rating: str = field(default="0.0")

    @property
    def title(self) -> str:
        return self._title

    @title.setter
    def title(self, value: str):
        if not isinstance(value, str):
            raise TypeError("Başlık bir string olmalıdır")
        
        # Boşlukları temizle
        cleaned_title = value.strip().replace('\n','')
        
        # Başlık için detaylı doğrulamalar
        if not cleaned_title:
            raise ValueError("Başlık boş olamaz")
        
        # Başlık uzunluk kontrolü
        MAX_TITLE_LENGTH = 200
        MIN_TITLE_LENGTH = 2
        
        if len(cleaned_title) < MIN_TITLE_LENGTH:
            raise ValueError(f"Başlık en az {MIN_TITLE_LENGTH} karakter olmalıdır")
        
        if len(cleaned_title) > MAX_TITLE_LENGTH:
            cleaned_title = cleaned_title[:MAX_TITLE_LENGTH] + "..."
        
        self._title = cleaned_title

    @property
    def year(self) -> str:
        return self._year

    @year.setter
    def year(self, value: str):
        if not isinstance(value, str):
            raise TypeError("Yıl bir string olmalıdır")
        
        # Boşlukları temizle
        cleaned_year = value.strip()
        
        # Yıl için detaylı doğrulamalar
        if not cleaned_year:
            raise ValueError("Yıl boş olamaz")
        
        self._year = cleaned_year

    @property
    def image(self) -> str:
        return self._image

    @image.setter
    def image(self, value: str):
        if not isinstance(value, str):
            raise TypeError("Görsel URL'si bir string olmalıdır")
        
        # Boşlukları temizle
        cleaned_image = value.strip()
        
        # Görsel URL kontrolü
        if not cleaned_image:
            raise ValueError("Görsel URL'si boş olamaz")
        
        # URL doğrulaması
        try:
            from urllib.parse import urlparse            
            urlparse(cleaned_image)        
        except ValueError as e:
            raise ValueError(f"Görsel URL Doğrulama Hatası: {e}")
        
        self._image = cleaned_image

    @property
    def rating(self) -> str:
        return self._rating

    @rating.setter
    def rating(self, value: str):
        if not isinstance(value, str):
            raise TypeError("Puan bir string olmalıdır")
        
        # Boşlukları temizle
        cleaned_rating = value.strip()
        
        if not cleaned_rating:
            raise ValueError("Puan boş olamaz")
        
        self._rating = cleaned_rating
@dataclass
class ListContent(BaseContent):
    """Docstring for Item."""
    _url: Optional[str] = None
  
    @property
    def url(self) -> Optional[str]:
        """URL getter metodu"""
        return self._url
    
    @url.setter
    def url(self, value: Optional[str]) -> None:
        """URL setter metodu ile doğrulama"""
        if value is None:
            self._url = None
            return
        
        try:
            # URL doğrulama
            result = urlparse(value)
            # Geçerli bir URL mi kontrol et
            if all([result.scheme, result.netloc]):
                self._url = value
            else:
                raise ValueError("Geçersiz URL formatı")
        except Exception as e:
            raise ValueError(f"URL doğrulama hatası: {e}")
