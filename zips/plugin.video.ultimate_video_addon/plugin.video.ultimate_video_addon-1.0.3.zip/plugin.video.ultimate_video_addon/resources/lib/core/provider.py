from abc import ABC, abstractmethod
from typing import List, Optional, Union

from model.chapter import Chapter
from model.media import Media
from model.movie import Movie
from model.serie import Serie
from model.video_content import ListContent


class Provider(ABC):
    """docstring for ClassName."""

    @classmethod
    @abstractmethod
    def Category(cls, category_id: str, page_number) -> Optional[List[ListContent]]:
        """docstring for getHomePage."""
        pass

    @classmethod
    @abstractmethod
    def load(cls, url: str, referer: str) -> Optional[Union[Movie, Serie, Chapter]]:
        """docstring for load."""
        pass

    @classmethod
    @abstractmethod
    def loadLinks(cls, url: str, referer: str) -> Optional[Media]:
        pass

    @classmethod
    @abstractmethod
    def search(cls, query: str) -> Optional[List[ListContent]]:
        pass
