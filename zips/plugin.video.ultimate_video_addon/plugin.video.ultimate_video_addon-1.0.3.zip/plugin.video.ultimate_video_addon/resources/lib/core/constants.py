from providers.hdfilmcehennemi import HdFilmCehenenmi
from providers.animecix import Animecix

PROVIDERS = {
    'hdfilm': HdFilmCehenenmi,
    'animecix': Animecix
}


