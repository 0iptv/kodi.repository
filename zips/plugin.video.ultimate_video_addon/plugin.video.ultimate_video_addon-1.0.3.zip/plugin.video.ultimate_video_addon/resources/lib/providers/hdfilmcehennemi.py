from typing import Any, Dict, List, Optional, Union
import re
import json

from bs4 import BeautifulSoup
from utils.parser import Parser
from model.chapter import Chapter
from utils.js2py import evalJS
from urllib.parse import urlparse

from integrations import api_connector
from security.encryption import unpack

from model.provider_options import ProviderOptions
from model.category import CategoryItem
from model.component import OtherComponent, SoupComponent
from core.provider import Provider
from model.media import Media
from model.video_content import ContentType
from model.movie import Movie
from model.serie import Serie
from model.video_content import ListContent
from services import content_service


HdFilmCehenenmi_Options = ProviderOptions(
    DOMAIN="www.hdfilmcehennemi.la",
    HEADERS={
        "Cookie": "DEVICE=Android; PRODUCT=RocketWeb; DEV_API=30; FCM_TOKEN=; ONE_SIGNAL_USER_ID=; _ga=GA1.1.871374070.1757599296; _ga_LR91MEQ0YR=GS2.1.s1757599295$o1$g1$t1757599637$j60$l0$h0",
        "User-Agent": "Mozilla/5.0 (Linux; Android 11; Fire 7 Build/RQ1A.210105.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.120 Safari/537.36",
        "X-Requested-With": "fetch",
        "Accept": "*/*",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9",
    },
    COMPONENTS={
        "MEDIA_MINI_GRID": SoupComponent(
            item_selector="div.columns > div.column-end > aside > section:nth-child(6) > div.section-content > div > a",
            child_selector={
                "title": "h4.mini-poster-title",
                "image": "img",
                "year": "div.mini-poster-meta > span:nth-child(2)",
                "rating": "span.mini-poster-imdb",
                "url": "",
            },
        ),
        "MEDIA_GRID": SoupComponent(
            item_selector="a.poster",
            child_selector={
                "title": "strong.poster-title",
                "image": "img",
                "year": "div.poster-meta > span:nth-child(1)",
                "rating": "span.imdb",
                "url": "",
            },
        ),
        "SERIE": SoupComponent(
            item_selector="",
            child_selector={
                "title": "h1.section-title",
                "image": "aside.post-info-poster > img",
                "year": "div.post-info-year-country > a:first-child",
                "rating": "div.post-info-imdb-rating > span",
                "genres": "div.post-info-genres > a",
                "plot": "article.post-info-content > p",
                "chapter_url": "div.seasons-tab-content >a",
                "chapter_title": "h4",
            },
        ),
        "MOVIE": SoupComponent(
            item_selector="",
            child_selector={
                "title": "h1.section-title",
                "image": "aside.post-info-poster > img",
                "year": "div.post-info-year-country > a:first-child",
                "rating": "div.post-info-imdb-rating > span",
                "genres": "div.post-info-genres > a",
                "plot": "article.post-info-content > p",
                "sources": "div.alternative-links > button",
                "source_attribute": "data-video",
            },
        ),
        "CHAPTER": SoupComponent(
            item_selector="div.alternative-links > button",
            child_selector={"source_attribute": "data-video"},
        ),
    },
    LOAD_LINK={
        "iframe1": {"selector": "iframe", "attribute": "data-src"},
        "iframe2": "(?P<eval>eval[^\n]*)(?:.*file:(?P<file>[^}]*)(?:.*tracks:[^[]*(?P<tracks>\\[[^]]*\\])?)?)?",
    },
)


def loadLinksParser(url: str, headers: Dict[str, str], load_link: Dict[str, Any]) -> Optional[Media]:
    html_content = api_connector.make_request(url, headers)
    if not html_content:
        return None
    soup = BeautifulSoup(html_content, "html.parser")
    parser = load_link["iframe1"]
    iframe1 = soup.select_one(parser.get("selector"))
    if iframe1:
        media = Media()
        attribute = parser.get("attribute")
        url = iframe1.get(attribute)
        url_domain = urlparse(url).netloc
        media.referer = f"{urlparse(url).scheme}://{url_domain}/"
        subtitle_domain=f"{urlparse(url).scheme}://{url_domain}"
        if "referer" in headers:
            referer = headers["referer"]
            referer_domain = urlparse(referer).netloc
            if url_domain != referer_domain:
                headers["referer"] = f"{urlparse(referer).scheme}://{referer_domain}/"

        html_content = api_connector.make_request(url, headers)
        if not html_content:
            return None
        regex_pattern = load_link["iframe2"]

        match = re.search(regex_pattern, html_content, re.DOTALL)

        if match:
            # Check if eval group was matched
            eval_content = match.group("eval") if "eval" in match.groupdict() and match.group("eval") else None
            # Check if file and tracks groups were matched
            file_content = match.group("file") if "file" in match.groupdict() and match.group("file") else None
            tracks_content = match.group("tracks") if "tracks" in match.groupdict() and match.group("tracks") else None
            if not tracks_content:
                soup = BeautifulSoup(html_content, "html.parser")
                tracks_html = soup.select("track")
                tracks: List[str] = []
                for track in tracks_html:
                    subtitle = subtitle_domain + track.get("src")
                    tracks.append(subtitle)
                if tracks:
                    media.subtitles = tracks
            else:
                tracks_json = json.loads(tracks_content)
                tracks = []
                for track in tracks_json:
                    subtitle = subtitle_domain + track.get("file")
                    tracks.append(subtitle)
                if tracks:
                    media.subtitles = tracks

            unpacked_eval = unpack(eval_content)
            if not file_content:
                file_content_regex = "{src:(?P<file>[^,]*),"
                file_content_parser = re.search(file_content_regex, unpacked_eval, re.DOTALL)
                if file_content_parser:
                    file_content = (
                        file_content_parser.group("file")
                        if "file" in file_content_parser.groupdict() and file_content_parser.group("file")
                        else None
                    )
            if file_content:
                eval_regex = file_content + "=(?P<decodeFn>(?P<decodeFnName>[^\(]*)[^;]*)"
                eval_parser = re.search(eval_regex, unpacked_eval, re.DOTALL)
                if eval_parser:
                    decodeFn = (
                        eval_parser.group("decodeFn")
                        if "decodeFn" in eval_parser.groupdict() and eval_parser.group("decodeFn")
                        else None
                    )
                    decodeFnName = (
                        eval_parser.group("decodeFnName")
                        if "decodeFnName" in eval_parser.groupdict() and eval_parser.group("decodeFnName")
                        else None
                    )
                    if decodeFnName and decodeFn:
                        decode_regex = f"(?P<decodeFnMethod>function {decodeFnName}.*?}})function"
                        decode_parser = re.search(decode_regex, unpacked_eval, re.DOTALL)
                        if decode_parser:
                            decodeFnMethod = (
                                decode_parser.group("decodeFnMethod")
                                if "decodeFnMethod" in decode_parser.groupdict()
                                and decode_parser.group("decodeFnMethod")
                                else None
                            )
                            if decodeFnMethod:
                                m3u8 = evalJS(f"function(){{{decodeFnMethod}return {decodeFn}}}")()
                                if m3u8:
                                    media.m3u8_url = m3u8
                                    return media

    return None


def fixData(data: Union[Movie, Serie, Chapter]) -> None:
    sources: List[str] = []
    if isinstance(data, Movie):
        data.rating = data.rating.split(" ")[0]
        for source in data.sources:
            sources.append(f"https://{HdFilmCehenenmi_Options.DOMAIN}/video/{source}/")
        data.sources = sources

    elif isinstance(data, Serie):
        data.rating = data.rating.split(" ")[0]
    elif isinstance(data, Chapter):
        for source in data.sources:
            sources.append(f"https://{HdFilmCehenenmi_Options.DOMAIN}/video/{source}/")
        data.sources = sources
        


def searchParser(url, headers) -> Optional[List[ListContent]]:
    response = api_connector.make_request(url, headers)
    if isinstance(response, str):
        json_content = json.loads(response)
    else:
        json_content = response
    if not json_content:
        return None
    results = json_content.get("results", None)
    if not results:
        return None
    if isinstance(results, list):
        html_content = " ".join(map(str, results))
        return Parser.parse_category(html_content, SEARCH)
    return None


def checkTypeContent(html_content: str) -> Optional[ContentType]:
    soup = BeautifulSoup(html_content, "html.parser")

    movie_tab = soup.select_one("div.post-info")
    seasons_tab = soup.select_one("div.seasons-tab-content")
    if movie_tab:
        if seasons_tab:
            return ContentType.SERIE
        else:
            return ContentType.MOVIE
    return ContentType.CHAPTER


SEARCH = SoupComponent(
    item_selector="a",
    child_selector={
        "title": "h4.title",
        "image": "img",
        "year": "span.year",
        "rating": "span.imdb",
        "url": "",
    },
)


class HdFilmCehenenmi(Provider):
    """docstring for HdFilmCehenenmi."""

    OPTIONS = HdFilmCehenenmi_Options
    NAME = "HDFILMCEHENNEMI"
    ICON= "hdfilm.png"
    CATEGORIES = {
        "populer_diziler": CategoryItem(
            name="Popüler Diziler",
            url=f"https://{HdFilmCehenenmi_Options.DOMAIN}/?router=1",
            is_paging=False,
            headers={
                **HdFilmCehenenmi_Options.HEADERS,
                "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/",
            },
            component=HdFilmCehenenmi_Options.COMPONENTS["MEDIA_MINI_GRID"],
        ),
        "yeni_eklenenler": CategoryItem(
            name="Yeni Eklenenler",
            url=f"https://{HdFilmCehenenmi_Options.DOMAIN}/load/page/{{page}}/home/",
            is_paging=True,
            headers={
                **HdFilmCehenenmi_Options.HEADERS,
                "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/",
            },
            component=HdFilmCehenenmi_Options.COMPONENTS["MEDIA_GRID"],
        ),
        "nette_ilk": CategoryItem(
            name="Nette İlk Filmler",
            url=f"https://{HdFilmCehenenmi_Options.DOMAIN}/load/page/{{page}}/categories/nette-ilk-filmler/",
            is_paging=True,
            headers={
                **HdFilmCehenenmi_Options.HEADERS,
                "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/category/nette-ilk-filmler/",
            },
            component=HdFilmCehenenmi_Options.COMPONENTS["MEDIA_GRID"],
        ),
        "tavsiye_filmler": CategoryItem(
            name="Tavsiye Filmler",
            url=f"https://{HdFilmCehenenmi_Options.DOMAIN}/load/page/{{page}}/categories/tavsiye-filmler-izle3/",
            is_paging=True,
            headers={
                **HdFilmCehenenmi_Options.HEADERS,
                "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/category/tavsiye-filmler-izle3/",
            },
            component=HdFilmCehenenmi_Options.COMPONENTS["MEDIA_GRID"],
        ),
        "imdb7": CategoryItem(
            name="IMDB 7 ÜZERİ FİLMLER",
            url=f"https://{HdFilmCehenenmi_Options.DOMAIN}/load/page/{{page}}/imdb7//",
            is_paging=True,
            headers={
                **HdFilmCehenenmi_Options.HEADERS,
                "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/imdb-7-puan-uzeri-filmler-1/",
            },
            component=HdFilmCehenenmi_Options.COMPONENTS["MEDIA_GRID"],
        ),
        "en_cok_yorumlananlar": CategoryItem(
            name="En Çok Yorumlananlar",
            url=f"https://{HdFilmCehenenmi_Options.DOMAIN}/load/page/{{page}}/mostCommented//",
            is_paging=True,
            headers={
                **HdFilmCehenenmi_Options.HEADERS,
                "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/en-cok-yorumlananlar-2/",
            },
            component=HdFilmCehenenmi_Options.COMPONENTS["MEDIA_GRID"],
        ),
        "en_cok_begenilenler": CategoryItem(
            name="En Çok Beğenilenler",
            url=f"https://{HdFilmCehenenmi_Options.DOMAIN}/load/page/{{page}}/mostLiked//",
            is_paging=True,
            headers={
                **HdFilmCehenenmi_Options.HEADERS,
                "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/en-cok-begenilen-filmleri-izle-1/",
            },
            component=HdFilmCehenenmi_Options.COMPONENTS["MEDIA_GRID"],
        ),
        "yabanci_diziler": CategoryItem(
            name="Yabancı Diziler",
            url=f"https://{HdFilmCehenenmi_Options.DOMAIN}/load/page/{{page}}/home-series/",
            is_paging=True,
            headers={
                **HdFilmCehenenmi_Options.HEADERS,
                "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/yabancidiziizle-4/",
            },
            component=HdFilmCehenenmi_Options.COMPONENTS["MEDIA_GRID"],
        ),
    }

    @classmethod
    def Category(cls, category_id: str, page_number=1) -> Optional[List[ListContent]]:
        category = cls.CATEGORIES.get(category_id, None)
        if not category:
            return None
        return content_service.get_category(category, page_number)

    @classmethod
    def load(cls, url: str, referer: str) -> Union[Movie, Serie, Chapter, None]:
        headers = {**HdFilmCehenenmi_Options.HEADERS, "referer": referer}
        result = content_service.load(
            url,
            headers,
            HdFilmCehenenmi_Options.COMPONENTS["MOVIE"],
            HdFilmCehenenmi_Options.COMPONENTS["SERIE"],
            HdFilmCehenenmi_Options.COMPONENTS["CHAPTER"],
            checkTypeContent,
        )
        if result:
            fixData(result)
        return result

    @classmethod
    def search(cls, query: str) -> Optional[List[ListContent]]:
        """searchde Content-Type: application/json ekleniyor headera Accepten once olacak ayrıca
        Mofycore-Router-Prefetch: false ekleniyor eğer ?router=1 isteği varsa
        """
        url = f"https://{HdFilmCehenenmi_Options.DOMAIN}/search?q={query}"
        headers = {
            **HdFilmCehenenmi_Options.HEADERS,
            "Content-Type": "application/json",
            "referer": f"https://{HdFilmCehenenmi_Options.DOMAIN}/",
        }
        return searchParser(url, headers)

    @classmethod
    def loadLinks(cls, url: str, referer: str) -> Optional[Media]:
        headers = {**HdFilmCehenenmi_Options.HEADERS, "referer": referer}
        return loadLinksParser(url, headers, HdFilmCehenenmi_Options.LOAD_LINK)
