import tls_client  # type: ignore
import json
from utils import logger

def make_request(url, headers):
    """
    Makes a GET request to the specified URL with the given headers using tls_client.
    Handles different response types based on Content-Type header.
    """
    try:
        # Create a tls_client session with a specific browser identifier
        session = tls_client.Session(
            client_identifier="chrome_120", random_tls_extension_order=True
        )

        # Make the request
        response = session.get(url, headers=headers, timeout_seconds=30)

        # Check if the request was successful (including redirects)
        if response.status_code is not None and 200 <= response.status_code < 400:
            content_type = response.headers.get("Content-Type", "")

            if "application/json" in content_type:
                try:
                    json_data = response.json()
                    result = json_data.get("html", None)
                    if result:
                        return result
                    else:
                        data = json_data.get("data", None)
                        if data and "html" in data:
                            return data.get("html", None)
                    return json_data
                except json.JSONDecodeError:
                    logger.log("Error: Failed to decode JSON.", logger.LOGERROR)
                    return None
            elif "text/html" in content_type:
                return response.text
            else:
                # Default to returning text if content type is unexpected but request was successful
                logger.log(f"Unexpected Content-Type: {content_type}. Returning raw text.", logger.LOGWARNING)
                return response.text
        else:
            # Handle error responses
            logger.log(f"Error status code: {response.status_code}", logger.LOGERROR)
            return None
    except Exception as e:
        # Handle request errors
        logger.log(f"Error making request to {url}: {e}", logger.LOGERROR)
        return None
