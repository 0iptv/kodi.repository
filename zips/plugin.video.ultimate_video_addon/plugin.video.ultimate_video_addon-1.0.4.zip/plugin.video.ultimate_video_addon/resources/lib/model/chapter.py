from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Chapter:
    """Docstring for Sources."""

    _sources: Optional[List[str]] = field(default=None)
    
    @property
    def sources(self) -> List[str]:
        return self._sources or [] 

    @sources.setter
    def sources(self, value: List[str]):
        # Doğrulama kontrolleri
        if not isinstance(value, list):
            raise TypeError("Sources bir liste olmalıdır")
        
        if not all(isinstance(item, str) for item in value):
            raise ValueError("Tüm source elemanları string olmalıdır")        
        
        cleaned_sources = list(dict.fromkeys(
            [source.strip() for source in value if source.strip()]
        ))
        
        self._sources = cleaned_sources