from dataclasses import dataclass
from typing import Any, Dict, Union

from model.component import OtherComponent, SoupComponent


@dataclass
class ProviderOptions(object):
    """Docstring for ProviderOptions."""

    DOMAIN: str
    HEADERS: Dict[str, str]
    COMPONENTS: Dict[str, Union[OtherComponent, SoupComponent]]
    LOAD_LINK: Dict[str, Any]
