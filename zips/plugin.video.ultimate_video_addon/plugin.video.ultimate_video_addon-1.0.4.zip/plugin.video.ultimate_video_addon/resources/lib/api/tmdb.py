from typing import List
import urllib.parse
from integrations import api_connector
from core.constants import tmdb_default_api

base_url = "https://api.themoviedb.org/3"
movies_append = "external_ids,videos,credits,release_dates,alternative_titles,translations,images"
tvshows_append = "external_ids,videos,credits,content_ratings,alternative_titles,translations,images"
timeout = 20.0
movie_genres = {
    28: "Aksiyon",
    12: "Macera",
    16: "Animasyon",
    35: "Komedi",
    80: "Suç",
    99: "Belgesel",
    18: "Dram",
    10751: "Aile",
    14: "Fantastik",
    36: "Tarih",
    27: "Korku",
    10402: "Müzik",
    9648: "Gizem",
    10749: "Romantik",
    878: "Bilim-Kurgu",
    10770: "TV film",
    53: "Gerilim",
    10752: "Savaş",
    37: "Vahşi Batı",
}

tv_genres = {
    10759: "Aksiyon & Macera",
    16: "Animasyon",
    35: "Komedi",
    80: "Suç",
    99: "Belgesel",
    18: "Dram",
    10751: "Aile",
    10762: "Çocuklar",
    9648: "Gizem",
    10763: "Haber",
    10764: "Gerçeklik",
    10765: "Bilim Kurgu & Fantazi",
    10766: "Pembe Dizi",
    10767: "Talk",
    10768: "Savaş & Politik",
    37: "Vahşi Batı",
}


def tmdb_search(query):
    encoded_query = urllib.parse.quote(query)
    url = "%s/search/multi?api_key=%s&language=tr-TR&include_adult=false&query=%s" % (base_url, tmdb_default_api, encoded_query)
    result = get_tmdb(url)
    if isinstance(result, dict) and result.get("total_results", 0) > 0:
        return result
    return None


def get_tmdb_genres(ids: List[int], type: str) -> List[str]:
    genres = movie_genres if type.lower() == "movie" else tv_genres
    if not isinstance(ids, list):
        ids = [ids]

    return [genres.get(id, f"Bilinmeyen Tür (ID: {id})") for id in ids]


def get_tmdb(url):
    try:
        response = api_connector.make_request(url, {"Accept": "application/json"})
    except:
        response = None
    return response
