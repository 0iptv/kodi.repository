from sys import platform
from platform import machine
import ctypes
import os


if platform == 'darwin':
    file_ext = '-arm64.dylib' if machine() == "arm64" else '-x86.dylib'
elif platform in ('win32', 'cygwin'):
    file_ext = '-64.dll' if 8 == ctypes.sizeof(ctypes.c_voidp) else '-32.dll'
else:
    # Linux/Unix sistemler için
    if 8 == ctypes.sizeof(ctypes.c_voidp):  # 64-bit uygulama
        if machine() == "aarch64":
            file_ext = '-arm64.so'
        elif "x86" in machine():
            file_ext = '-x86.so'
        else:
            file_ext = '-amd64.so'
    else:  # 32-bit uygulama
        if machine() in ["aarch64", "arm64", "armv7l", "armv6l"]:
            file_ext = '-linux-armv7.so'  # 32-bit ARM için
        elif "x86" in machine() or "i386" in machine() or "i686" in machine():
            file_ext = '-x86.so'  # 32-bit x86 için
        else:
            file_ext = '-linux-armv7.so'  # varsayılan olarak ARM

root_dir = os.path.abspath(os.path.dirname(__file__))
library = ctypes.cdll.LoadLibrary(f'{root_dir}/dependencies/tls-client{file_ext}')

# extract the exposed request function from the shared package
request = library.request
request.argtypes = [ctypes.c_char_p]
request.restype = ctypes.c_char_p

freeMemory = library.freeMemory
freeMemory.argtypes = [ctypes.c_char_p]
freeMemory.restype = ctypes.c_char_p

destroySession = library.destroySession
destroySession.argtypes = [ctypes.c_char_p]
destroySession.restype = ctypes.c_char_p
