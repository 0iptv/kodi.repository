#  _____  __  __         ___ _ _            _
# /__   \/ / / _\       / __\ (_) ___ _ __ | |_
#   / /\/ /  \ \ _____ / /  | | |/ _ \ '_ \| __|
#  / / / /____\ \_____/ /___| | |  __/ | | | |_
#  \/  \____/\__/     \____/|_|_|\___|_| |_|\__|

__title__ = "tls_client"
__description__ = "Advanced Python HTTP Client."
__version__ = "1.0.1"
__author__ = "Florian Zager"
__license__ = "MIT"