
class TLSClientExeption(IOError):
    """General error with the TLS client"""